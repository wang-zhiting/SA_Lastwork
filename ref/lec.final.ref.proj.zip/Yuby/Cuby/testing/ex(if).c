int main(){
    int a = 2;
    if (a == 1){
        print 1;
    }else if(a == 3){
        print 3;
    }else if(a == 4){
        print 4;
    }else if(a == 2){
        print 2;
    }

}