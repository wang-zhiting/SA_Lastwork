#include "stdafx.h"
#include "define.h"
#include <stdlib.h>
#include <stdio.h>
#include "asm.h"
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
extern info Table[200];/////info table
extern middlecode code[1000];/////middle code
extern int codenum;

void asmhead();
void datasegment();
void procasm();
void popreg();
void getvalueofarry(char *s);
int findarraybase(char* s);

void Destroy(AddTable* head);
AddTable* search(AddTable * head, char *id);
//FILE * asmin;
int asmindex=0;
int asmindex22=0;

int counter=0;////�ֲ���������ʱ��������
int varc=0;
int push = 0;////�����������õ�ʱ�򴫲�(call)

int functiontype=-1;
char str[30];////���ú������õ�
char templab='n';
int templabnumber=0;



AddTable *h1 = NULL,*h2 = NULL,*h3=NULL,*tp1,*he1,*he2;
/////h1 �ֲ������ͳ�����ͷ�� h2  ��ʱ������ͷ��h3��ȫ�ֳ����ͱ�����ͷ�� ʣ�µ�����ָ�룬tp���������ڴ�ռ䣬
/////heָ��ָ��Ķ��Ǹ���������ĩβ���������������ã�he1�ڽ���ȫ�ֱ�ʱָ��ȫ�ֱ�β����������ȫ�ֱ�֮��ָ��ֲ���β����
AddTable  *read;

ofstream asmout ("asm.asm");
void toasm(){
    asmhead();
    asmout<<";----------code segment-------"<<endl;
    datasegment();
    asmout<<";datamen over"<<endl;
    procasm();

}
void asmhead(){
   asmout<<".386"<<endl;
   asmout<<".model flat,stdcall"<<endl;
   asmout<<"option casemap:none"<<endl;
   asmout<<"Include c:\\masm32\\include\\windows.inc"<<endl;
   asmout<<"Include c:\\masm32\\include\\kernel32.inc"<<endl;
   asmout<<"Include c:\\masm32\\include\\msvcrt.inc"<<endl;
   asmout<<"Includelib c:\\masm32\\lib\\msvcrt.lib"<<endl;
   asmout<<"Includelib c:\\masm32\\lib\\kernel32.lib"<<endl;
   asmout<<"Include c:\\masm32\\macros\\macros.asm"<<endl;

}

void datasegment(){//////ȫ�����ݶ�
    asmout<<".data"<<endl;
   // asmout<<"_temp_for_print dword ?"<<endl;
   while (strcmp(code[asmindex].op,"const")==0) {////ȫ�ֳ�������
       int temptype=0;
        if (strcmp(code[asmindex].var1,"int")==0)
            { asmout<<"\t_"<<code[asmindex].var3<<'\t'<<"equ"<<'\t'<<code[asmindex].var2<<endl; temptype=0;}
		else
			{ asmout<<"\t_"<<code[asmindex].var3<<'\t'<<"equ"<<'\t'<<"\'"<<code[asmindex].var2<<"\'"<<endl;temptype=1;}
		tp1 = (AddTable*)malloc(sizeof(AddTable));////h3��ȫ�ֳ��������ı�ͷ
		strcpy(tp1->id,code[asmindex].var3);
		tp1->add = 0;
		tp1->next = NULL;
        tp1->type=temptype;
		if(h3 == NULL)////he1����������������
		{
			h3 = tp1;
			he1 = tp1;
		}
		else
		{
			he1->next = tp1;
			he1 = he1->next;
		}
		asmindex++;
	}
	while(strcmp(code[asmindex].op,"int")==0|| strcmp(code[asmindex].op,"char")==0)
	   {    /////ȫ�ֱ�������
	      if(strcmp(code[asmindex].var2," ")!=0){/////����ȫ�ֱ�������,��һ���ԡ���
                int valueofarray = atoi(code[asmindex].var2);
                char temp_1[20];
                strcpy(temp_1,code[asmindex].var3);
                asmout<<'\t'<<temp_1<<'\t'<<"DWORD"<<'\t'<<valueofarray<<" DUP(?)"<<endl;
                for(int i=0;i<valueofarray;i++){
                      char number_of_array[20];
                      char temp_2[20];
                      strcpy(temp_2,temp_1);
                      itoa(i,number_of_array,10);
                      strcat(temp_2,"[");
                      strcat(temp_2,number_of_array);
                      strcat(temp_2,"]");
                      tp1 = (AddTable*)malloc(sizeof(AddTable));
                      tp1->add = 0;////counter�Ǿֲ������ļ�������ǰ���Ǹ�����ΪX86��ջ��ַ����������������ջ���ǵ͵�ַ����ebp+���λ�Ʋ��ǵ�ַ
			          tp1->next = NULL;

			           if(strcmp(code[asmindex].op,"int")==0)
                       tp1->type=0;

                       if(strcmp(code[asmindex].op,"char")==0)
                        tp1->type=1;

                      strcpy(tp1->id,temp_2);/////change[0],change[1],change[2],change[3]������������

			          if(h3 == NULL)////he1����������������
		               {
			              h3 = tp1;
			              he1 = tp1;
		                }
		               else
		               {
			              he1->next = tp1;
			              he1 = he1->next;
		                }
                     }
			    }
	    else {/////��ͨȫ�ֱ���
		asmout<<"\t_"<<code[asmindex].var3<<'\t'<<"dword"<<'\t'<<"?"<<endl;
        tp1 = (AddTable*)malloc(sizeof(AddTable));////h3��ȫ�ֳ��������ı�ͷ
		strcpy(tp1->id,code[asmindex].var3);
		tp1->add = 0;
		tp1->next = NULL;

         if(strcmp(code[asmindex].op,"int")==0)
         tp1->type=0;

         if(strcmp(code[asmindex].op,"char")==0)
         tp1->type=1;

		if(h3 == NULL)////he1����������������
		{
			h3 = tp1;
			he1 = tp1;
		}
		else
		{
			he1->next = tp1;
			he1 = he1->next;
		}
      }
		asmindex++;
	}
    asmout<<endl;
}



void procasm(){
    char function[20];
    asmout<<"z dword  50 dup(?)"<<endl;//////�������ݶκ�invoke�������ʽ�洢��ͻ�������������Բŷ��֡�
    asmout<<";-----------CODE SEGMENT"<<endl;
    asmout<<".CODE"<<endl;

    while(asmindex<codenum){
            //���
       if(strcmp(code[asmindex].op,"setlab")==0){
                asmout<<code[asmindex].var3<<":"<<endl;
             }
       else if(strcmp(code[asmindex].op,"start")==0&&(strcmp(code[asmindex].var3,"main")!=0)){////һ���Ӻ���
          counter=0;
          varc=0;
          asmindex22 = asmindex+1;
          if(strcmp(code[asmindex].var1,"char")==0)
            functiontype=1;
          if(strcmp(code[asmindex].var1,"int")==0)
            functiontype=0;
          if(strcmp(code[asmindex].var1,"void")==0)
            functiontype=2;
          asmout<<'_'<<code[asmindex].var3<<'\t'<<"PROC"<<endl;
          ///get1s PROC  NEAR32
          while(strcmp(code[asmindex22].op,"para")==0){/////ͳ�Ʋ������������洦���βλ��õ�varc
              varc++;
             // asmout<<code[asmindex22].var3<<":dword";
              asmindex22++;
             // if(strcmp(code[asmindex22].op,"para")==0)////��������βδ�ӡ,����س�
               // asmout<<',';
              //  else asmout<<endl;
              }
            strcpy(function,code[asmindex].var3);

            asmout<<";-------------------�����ֳ�---------"<<endl;
            asmout<<'\t'<<"push"<<'\t'<<"ebx"<<endl;
			asmout<<'\t'<<"push"<<'\t'<<"ecx"<<endl;
			asmout<<'\t'<<"push"<<'\t'<<"edx"<<endl;
			asmout<<'\t'<<"push"<<'\t'<<"esi"<<endl;
			asmout<<'\t'<<"push"<<'\t'<<"edi"<<endl;
            asmout<<'\t'<<"push"<<'\t'<<"ebp"<<endl;/// push	ebp/////���ú�����ebp��֮ǰ��һ����retadress
            asmout<<'\t'<<"mov"<<'\t'<<"ebp,"<<'\t'<<"esp"<<endl; /// mov	ebp,	esp  EBPָ����ǵ�ǰ�����Ļ���ַ
            asmout<<";-------------------�����ֳ�����---------"<<endl;
			///Ȼ���ǰѴ����ֵ�;ֲ������ٽ�һ������������<-->��ַ����ԣ�������ΪEBP+,�ֲ�����ΪEBP-
			/// �Ժ��������ʱ���������������Ҫ�Ļ�����ѹջ��������
          }

      else if(strcmp(code[asmindex].op,"start") == 0 && strcmp(code[asmindex].var3,"main") == 0)   // the main function
		{
			asmout<<"START:"<<endl;
			asmout<<'\t'<<"push"<<'\t'<<"ebp"<<endl;
			asmout<<'\t'<<"mov"<<'\t'<<"ebp,"<<'\t'<<"esp"<<endl;
			strcpy(function,"main");
			counter = 0;
		}
		///TODO:
      else if(strcmp(code[asmindex].op,"end")==0&&strcmp(code[asmindex].var3,"main")!=0){////��������
            //asmout<<'\t'<<"add"<<'\t'<<"esp,"<<'\t'<<4*counter<<endl;
            asmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
			popreg();					 	// �˳��Ĵ���
            asmout<<'\t'<<"ret"<<endl;
			counter = 0;						// �����������ü�����Ϊ0
            Destroy(h1);                        //�������ڵľֲ��������Լ���ʱ������ȫ�����
			h1 = NULL;
			Destroy(h2);
			h2 = NULL;
			asmout<<'_'<<function<<"\tendp"<<endl;
      }
      else if(strcmp(code[asmindex].op,"end") == 0  && strcmp(function,"main") == 0){/////main ��������

			asmout<<'\t'<<"pop"<<'\t'<<"ebp"<<endl;
			asmout<<"   invoke ExitProcess, 0; exit with code 0"<<endl;
			asmout<<"END START"<<endl;
			h1 = NULL;
			h2 = NULL;
            counter = 0;
          }
      else if(strcmp(code[asmindex].op,"parav") == 0)		// ��������ʱ��ֵ  push vparameter,���������д�ڴ�?
		{
			push ++;
			read = search(h1,code[asmindex].var3);			// ���Ҫ��ѭһ����ԭ���ȵ�����ֲ�����(���������β�Ҳ��ֲ�����)�����ҡ�
			if(read == NULL)                    // ȥ��ʱ�����ҡ�
			{
				read = search(h2,code[asmindex].var3);
				if(read == NULL)                // ���û�ҵ���Ҫô��const���͵ģ�Ҫô���ǳ���,����ֱ�������Ϊ����
				{
                    read=search(h3,code[asmindex].var3);
                    if(read==NULL){/////���Ҳ�����Ҫô�Ǹ�������Ҫô�Ǹ��������
                         //ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////����
                            {
                                if(code[asmindex].var3[0]>='0'&&code[asmindex].var3[0]<='9')
                                asmout<<"\tmov\teax,\t"<<code[asmindex].var3<<endl;
                                else
                                asmout<<"\tmov\teax,\t\'"<<code[asmindex].var3<<"\'"<<endl;
                            }
                            else {////����
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var3,temp);
                            int d=findarraybase(temp);
                            if(d==-1)
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var3<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }

                        }

                    }

					else////��ȫ�ֱ���
                    {
                        int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                asmout<<"\tmov\teax,\t_"<<code[asmindex].var3<<endl;
                            }
                            else {////����
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var3,temp);
                            int d=findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var3<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                     }

                    }


					asmout<<"\t;to pass values to the function"<<endl;
					asmout<<"\tpush\teax"<<endl;////����ѹջ
				}
				else////����ʱ�����������ҵ���
				{
                    asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
					asmout<<"\t;to pass values to the function"<<endl;
					asmout<<"\tpush\teax"<<endl;//����ѹջ
				}
			}
			else////�ھֲ����������ҵ���
			{
				    asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
					asmout<<"\t;to pass values to the function"<<endl;
					asmout<<"\tpush\teax"<<endl;//����ѹջ
			}
		}
		else if(strcmp(code[asmindex].op,"int")==0||strcmp(code[asmindex].op,"char")==0){/////�ֲ�����,��Ϊȫ�ֱ����Ѿ�Ū���ˡ���

			if(strcmp(code[asmindex].var2," ")!=0){/////�������Ҫ������������ַ
                int valueofarray = atoi(code[asmindex].var2);
                char temp_1[20];
                strcpy(temp_1,code[asmindex].var3);
                for(int i=0;i<valueofarray;i++){
                      char number_of_array[20];
                      char temp_2[20];
                      strcpy(temp_2,temp_1);
                      itoa(i,number_of_array,10);
                      strcat(temp_2,"[");
                      strcat(temp_2,number_of_array);
                      strcat(temp_2,"]");
                      tp1 = (AddTable*)malloc(sizeof(AddTable));
                      tp1->add = (-1)*4*(++counter);////counter�Ǿֲ������ļ�������ǰ���Ǹ�����ΪX86��ջ��ַ����������������ջ���ǵ͵�ַ����ebp+���λ�Ʋ��ǵ�ַ
			          tp1->next = NULL;
			          if(strcmp(code[asmindex].op,"char")==0)
                        tp1->type=1;
			          if(strcmp(code[asmindex].op,"int")==0)
                        tp1->type=0;

                      strcpy(tp1->id,temp_2);/////change[0],change[1],change[2],change[3]������������
                      asmout<<"\tmov\teax,\t"<<'0'<<";Define Local Variables"<<endl;////������ֵĬ��Ϊ0
			          asmout<<"\tpush\teax"<<endl;////�ֲ�����ѹջ
			          if(h1 == NULL)                                                // �����ֲ����ű���
			           {
				       h1 = tp1;
				       he1 = tp1;
			           }
			           else
			           {
				       he1->next = tp1;
				       he1 = he1->next;
			             }
                        }
			    }
			else {///�ֲ���������
              tp1 = (AddTable*)malloc(sizeof(AddTable));
              tp1->add = (-1)*4*(++counter);/////������:counter�Ǿֲ������ļ�������Ϊʲôǰ���Ǹ��ţ���ΪX86��ջ��ַ��������������ջ���ǵ͵�ַ����
			  tp1->next = NULL;
			  if(strcmp(code[asmindex].op,"char")==0)
                        tp1->type=1;
              if(strcmp(code[asmindex].op,"int")==0)
                        tp1->type=0;

              strcpy(tp1->id,code[asmindex].var3);
              asmout<<"\tmov\teax,\t"<<'0'<<";Define Local Variables"<<endl;///������ֵĬ��Ϊ0
			  asmout<<"\tpush\teax"<<endl;
			  if(h1 == NULL)                                                // �����ֲ����ű���
			  {
				h1 = tp1;
				he1 = tp1;
			  }
			  else
			  {
				he1->next = tp1;
				he1 = he1->next;
			  }
			}
         }
         else if(strcmp(code[asmindex].op,"const")==0)////�ֲ���������
            {
                int temptype=0;
                if (strcmp(code[asmindex].var1,"int")==0)
                {
                    asmout<<"\tmov\teax,\t"<<code[asmindex].var2<<";Define Local Const Variables"<<endl;///
                    temptype=0;
                    }
		          else
			    {
			        asmout<<"\tmov\teax,\t\'"<<code[asmindex].var2<<"\';Define Local Const Variables"<<endl;///
			        temptype=1;
			        }
              tp1 = (AddTable*)malloc(sizeof(AddTable));
              tp1->add = (-1)*4*(++counter);/////������:counter�Ǿֲ������ļ�������Ϊʲôǰ���Ǹ��ţ���ΪX86��ջ��ַ��������������ջ���ǵ͵�ַ����
			  tp1->next = NULL;
              tp1->type=temptype;
              strcpy(tp1->id,code[asmindex].var3);
			  asmout<<"\tpush\teax"<<endl;
			  if(h1 == NULL)                                                // �����ֲ����ű���
			  {
				h1 = tp1;
				he1 = tp1;
			  }
			  else
			  {
				he1->next = tp1;
				he1 = he1->next;
			  }
            }
         else if(strcmp(code[asmindex].op,"para") == 0) // �г��������β���ָ��ĵ�ַ
		{
			tp1 = (AddTable*)malloc(sizeof(AddTable));
			tp1->add = 4 * (6 + varc--);///�����ֳ�5���Ĵ�����push��һ��retaddress����Ӧ��+6,varc--�������ǵ���ѹջ ����һ������������ջ��
			///�βε�ַӦ��ָ��ʵ�ε�ʵ�ʵ�ַ��ʵ�ε�ַ�����ں�����ebp�·����ɵ����߾����ģ�
			////��ǰ��espΪebp
			tp1->next = NULL;
			strcpy(tp1->id,code[asmindex].var3);
            if(strcmp(code[asmindex].var1,"char") == 0)
            tp1->type=1;
            if(strcmp(code[asmindex].var1,"int") == 0)
            tp1->type=0;
			if(h1 == NULL)
			{
				h1  = tp1;///�β��ں����ڱ�ʹ��ʱҲ�����ֲ�����
				he1 = tp1;
			}
			else
			{
				he1->next = tp1;
				he1 = he1->next;
			}
		}
		else if(strcmp(code[asmindex].op,"add") == 0 || strcmp(code[asmindex].op,"sub") == 0 || strcmp(code[asmindex].op,"mul") == 0 || strcmp(code[asmindex].op,"div") == 0) // + - * /
           {
               int temptype1=0;
               int temptype2=0;
               // ��2������
			read = search(h1,code[asmindex].var2);//////��2��ԭ�������Ƿ��Ǿֲ�����
			if(read == NULL)
			{
				read = search(h2,code[asmindex].var2);/////�Ƿ���ʱ����
				if(read == NULL)
				{

				//////ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                read=search(h3,code[asmindex].var2);
                                if(read==NULL){////����
                                    if(code[asmindex].var2[0]>='0'&&code[asmindex].var2[0]<='9')
                                    asmout<<"\tmov\teax,\t"<<code[asmindex].var2<<endl;
                                    else
                                     asmout<<"\tmov\teax,\t\'"<<code[asmindex].var2<<'\''<<endl;
                                }

                                else{
                                     asmout<<"\tmov\teax,\t_"<<code[asmindex].var2<<endl;
                                     temptype2=read->type;
                                }

                            }
                            else {////����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                read=search(h3,code[asmindex].var2);
                                temptype2=read->type;

                                for(;i<templen;i++)
                                temp[i]='\0';/////ȥ������ķ�����

                            strcpy(code[asmindex].var2,temp);
                            int d=findarraybase(code[asmindex].var2);
                            if(d==-1)
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var2<<"+4*ecx"<<"]"<<endl;
                            else{
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }

                            }


				}
				else////����ʱ����
				{
                    asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
                    temptype2=read->type;
				}
			}
			else ////�Ǿֲ�����
			{
				asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
				temptype2=read->type;
			}

			asmout<<"\tmov\tebx,\teax"<<endl;/////��2��������������ebx

			// ��1��Դ������
			read = search(h1,code[asmindex].var1);
			if(read == NULL)
			{
				read = search(h2,code[asmindex].var1);
				if(read == NULL)
				{
				    //ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                read=search(h3,code[asmindex].var1);
                                 if(read==NULL){////����
                                    if(code[asmindex].var1[0]>='0'&&code[asmindex].var1[0]<='9')
                                    asmout<<"\tmov\teax,\t"<<code[asmindex].var1<<endl;
                                    else
                                     asmout<<"\tmov\teax,\t\'"<<code[asmindex].var1<<'\''<<endl;
                                }
                                else{
                                    asmout<<"\tmov\teax,\t_"<<code[asmindex].var1<<endl;
                                    temptype1=read->type;
                                }

                            }
                            else {////����
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                read=search(h3,code[asmindex].var1);
                                temptype1=read->type;
                                for(;i<templen;i++)
                                temp[i]='\0';
                            strcpy(code[asmindex].var1,temp);
                            int d=findarraybase(temp);
                            if(d==-1)
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }

                            }

					//asmout<<"\tmov\teax,\t"<<code[asmindex].var1<<endl;
				}
				else////����ʱ����
				{
					 asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
					 temptype1=read->type;
				}
			}
			else////�Ǿֲ�����
			{
				asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
				temptype1=read->type;
			}

			// deal with the operand
			if(strcmp(code[asmindex].op,"add") == 0 || strcmp(code[asmindex].op,"sub") == 0)
			{
				asmout<<'\t'<<code[asmindex].op<<"\teax,\tebx"<<endl;/////add eax, ebx��sub eax,ebx
			}
			else/////imul ,div ebx   /////�˳�����ʱ��Ҫ����չָ��.
			{
			    asmout<<"\tcdq"<<endl;
				asmout<<"\ti"<<code[asmindex].op<<"\tebx"<<endl;///eax=eax*/ebx
			}

			// ���������������ֵ

			read = search(h1,code[asmindex].var3);
			if(read == NULL)///��ʱ����
			{
				read = search(h2,code[asmindex].var3);////����ʱ�������в���
				if(read == NULL)
				{
					read = search(h3,code[asmindex].var3);///��Ҫ�ǲ���ȫ�ֵı���
					if(read == NULL)   // ������Ҳ�����˵�����Ǹ��µ���ʱ����
					{
						tp1 = (AddTable *)malloc(sizeof(AddTable));
						strcpy(tp1->id,code[asmindex].var3);
						tp1->add = (-4)*(++counter) ;
						tp1->next = NULL;
                        if(temptype1==1&&temptype2==1)
                            tp1->type=0;
                        else
                            tp1->type=0;
						if(h2 == NULL)///�������ʱ�������ڷ�����ʱ����������
						{
							h2 = tp1;
							he2 = tp1;
						}
						else
						{
							he2->next = tp1;
							he2 = he2->next;
						}
                          asmout<<"\tmov\tdword  ptr [ebp+("<<tp1->add<<")],\teax"<<endl;/////��ʱ���������ڴ��С�������������
                          asmout<<"\tmov   ecx,ebp"<<endl;
                          asmout<<"\tadd   ecx,"<<tp1->add<<endl;
                          asmout<<"\tcmp   esp ,ecx"<<endl;
                          asmout<<"\tjle  labn"<<templabnumber<<endl;
                          asmout<<"\tmov esp, ecx"<<endl;
                          asmout<<"lab"<<templab<<templabnumber<<":"<<endl;////////֮������ôд��Ϊ���Ǳ�֤ѭ����ʱ����ʱ����ֻ��pushһ��.
                          templabnumber++;
					}
					else				//Ϊȫ�ֱ���
					{
						asmout<<"\tmov _"<<code[asmindex].var3<<",\teax"<<endl;
						if(temptype1==1&&temptype2==1)
                            read->type=0;
                        else
                            read->type=0;
					}
				}
				else////��ʱ����
				{
					asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
					if(temptype1==1&&temptype2==1)
                       read->type=0;
                    else
                       read->type=0;
				}
			}
			else////�ֲ�����
			{
				asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
				if(temptype1==1&&temptype2==1)
                read->type=0;
                else
                read->type=0;
			}

           }
           else if(strcmp(code[asmindex].op,"scanf") == 0) // the read sb statement
		   {
			read = search(h1,code[asmindex].var3);
			if(read == NULL)
			{
				read = search(h2,code[asmindex].var3);
				if(read == NULL)////����ȫ�ֱ���
				{
					if(strcmp(code[asmindex].var1,"int")==0)//////scanf int  a
					asmout<<"\tinvoke crt_scanf,SADD(\"%d\"),addr _"<<code[asmindex].var3<<endl;
					else if(strcmp(code[asmindex].var1,"char")==0)
                    asmout<<"\tinvoke crt_scanf,SADD(\"%c\"),addr _"<<code[asmindex].var3<<endl;
                }
				else//// ��ʱ����
				{
					if(strcmp(code[asmindex].var1,"int")==0)
					asmout<<"\tinvoke crt_scanf,SADD(\"%d\"),addr "<<"dword ptr[ebp+("<<read->add<<")]"<<endl;////invoke crt_scanf,SADD("%d"),addr dword ptr [ebp]
					else if(strcmp(code[asmindex].var1,"char")==0)
                    asmout<<"\tinvoke crt_scanf,SADD(\"%c\"),addr "<<"dword ptr[ebp+("<<read->add<<")]"<<endl;
				}
			}
			else  // �ֲ�����
			{
				if(strcmp(code[asmindex].var1,"int")==0)
				asmout<<"\tinvoke crt_scanf,SADD(\"%d\"),addr "<<"dword ptr[ebp+("<<read->add<<")]"<<endl;////invoke crt_scanf,SADD("%d"),addr dword ptr [ebp]
				else if(strcmp(code[asmindex].var1,"char")==0)
                asmout<<"\tinvoke crt_scanf,SADD(\"%c\"),addr "<<"dword ptr[ebp+("<<read->add<<")]"<<endl;
			}
		}

        else if(strcmp(code[asmindex].op,"print") == 0)  // the write statement
		{
		     asmout<<";print begin===="<<endl;
		     asmout<<"\tpush eax"<<endl;
			if(strcmp(code[asmindex].var1,"\0") != 0)/////���ַ���������ȴ�ӡ�ַ���
			{
                char buf[100];
                strcpy(buf,code[asmindex].var1);
                asmout<<";print string===="<<endl;
                asmout<<"invoke crt_printf,ADDR literal(\""<<buf<<"\")"<<endl;
                asmout<<"invoke crt_printf,SADD(\"%c\"),"<<10<<endl;
                asmout<<";print string over===="<<endl;
			}
			if(strcmp(code[asmindex].var2," ")!=0)/////��ӡ�Ķ����б���ʽ
			{
				read = search(h1,code[asmindex].var2);////�ھֲ�����������
				if(read == NULL)
				{
					read = search(h2,code[asmindex].var2);                      // h2����ʱ������ͷ
					if(read == NULL)
					{
					        //AddTable* readtemp=read;////getvalueofarray()������ı�readָ�룬��ӡ���ܳ���
						    /////�ھֲ���������ʱ���������Ҳ�����Ҫô��ȫ�ֱ���Ҫô�����顣
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen){////��������
                            read = search(h3,code[asmindex].var2);
                            if(read == NULL)   // ��ʱ�����Ǵ��һ�����������ַ��ˡ�
						     {
						    if(code[asmindex].var2[0]>='0'&&code[asmindex].var2[0]<='9')
                             {
                                asmout<<"\tmov\teax,\t"<<code[asmindex].var2<<endl;
                                asmout<<"invoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;////��ӡ����
                             }
                             else{
                                asmout<<"\tmov\teax,\t\'"<<code[asmindex].var2<<"\'"<<endl;
                                asmout<<"invoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
                            }
                          }
                          else {////��ͨȫ�ֱ���
                                asmout<<"\tmov\teax,\t_"<<code[asmindex].var2<<endl;
                                if(read->type==0)
                                asmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                                if(read->type==1)
                                asmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                          }
                        }

						else////������
						{
						    AddTable* readtemp=read;////getvalueofarray()������ı�readָ�룬��ӡ���ܳ���
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                asmout<<"\tmov\teax,\t_"<<code[asmindex].var2<<endl;
                                if(read->type==0)
                                asmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                                if(read->type==1)
                                asmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                            }
                            else {////�������
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }

                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);////��Ϊ���������ı�read
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var2,temp);
                                int d=findarraybase(temp);
                                if(d==-1)////ȫ���������
                                 {
                                     asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var2<<"+4*ecx]"<<endl;
                                     strcat(temp,"[0]");
                                     readtemp = search(h3,temp);
                                 }
                                else
                                {
                                    strcat(temp,"[0]");
                                    readtemp=search(h1,temp);
                                    asmout<<"\tneg ecx"<<endl;
                                    asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                                }
                                if(readtemp->type==0)
                                asmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;
                                if(readtemp->type==1)
                                asmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
                                }

						}
					}
					else/////�Ǹ���ʱ����
					{
						asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
						if(read->type==0)
                        asmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;
                        if(read->type==1)
                        asmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
					}
				}
				else///�Ǹ��ֲ�����
				{

					asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
					if(read->type==0)
                    asmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;
                    if(read->type==1)
                    asmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
				}
			}
			 asmout<<"\tpop eax"<<endl;
			 asmout<<";print over===="<<endl;
		}


		else if(strcmp(code[asmindex].op,"call") == 0)  // call functions
		{
		    char tempstr[30];
			strcpy(str,code[asmindex].var1);
			strcpy(tempstr,code[asmindex].var3);
			asmout<<"\tcall\t_"<<str<<endl;
			///��������ǰ����push++��
			asmout<<"\tadd\tesp,\t"<<4*push<<endl;////���κ������ù����������
			push = 0;///���pushֵ
			//asmindex++;
			/////�����������������ķ���ֵ����Ҫ��(�������Ӳ�������)
			//if(asmindex<codenum && strcmp(code[asmindex].op,"mov") == 0 && strcmp() == 0 )
			if(asmindex<codenum && strcmp(tempstr," ") != 0 )/////������Ϊ����
			{
				read = search(h1,tempstr);
				if(read != NULL)
				{
					asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
                    if(strcmp(code[asmindex].var2,"int") == 0)
                        read->type=0;
                    if(strcmp(code[asmindex].var2,"char") == 0)
                        read->type=1;
				}
				else
				{
					read = search(h2,tempstr);
					if(read == NULL)
					{
						read = search(h3,tempstr);
						if(read == NULL)// �����ʱ�����������ɵģ���Ҫ��������ռ䡣
						{
							tp1 = (AddTable*)malloc(sizeof(AddTable));
							tp1->add = (-1)*4*(++counter);
							strcpy(tp1->id,tempstr);
							tp1->next = NULL;
							if(strcmp(code[asmindex].var2,"int") == 0)
                                  tp1->type=0;
                            if(strcmp(code[asmindex].var2,"char") == 0)
                                  tp1->type=1;
							asmout<<"\tmov\tdword  ptr [ebp+("<<tp1->add<<")],\teax"<<endl;/////��ʱ���������ڴ��С�������������
                            asmout<<"\tmov   ecx,ebp"<<endl;
                            asmout<<"\tadd   ecx,"<<tp1->add<<endl;
                            asmout<<"\tcmp   esp ,ecx"<<endl;
                            asmout<<"\tjle  labn"<<templabnumber<<endl;
                            asmout<<"\tmov esp, ecx"<<endl;
                            asmout<<"lab"<<templab<<templabnumber<<":"<<endl;////////֮������ôд��Ϊ���Ǳ�֤ѭ����ʱ����ʱ����ֻ��pushһ��.
                            templabnumber++;
							if(h2 == NULL)
							{
								h2 = tp1;
								he2 = tp1;
							}
							else
							{
								he2->next = tp1;
								he2 = he2->next;
							}
						}
						else
						{
							asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
							if(strcmp(code[asmindex].var2,"int") == 0)
                                 read->type=0;
                             if(strcmp(code[asmindex].var2,"char") == 0)
                                read->type=1;
						}
					}
					else
					{
						asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
						if(strcmp(code[asmindex].var2,"int") == 0)
                           read->type=0;
                       if(strcmp(code[asmindex].var2,"char") == 0)
                           read->type=1;
					}
				}
			}
			else
				{asmindex++; continue;}
		}



		else if(strcmp(code[asmindex].op,"mov") == 0)  // mov src1,src2,src3
		{
			// ��һ��ָ��ѵ�1���������ŵ��Ĵ�����
			int temptype=0;
			read = search(h1,code[asmindex].var1);
			if(read == NULL)
			{
				read =search(h2,code[asmindex].var1);
				if(read == NULL)
				{
					read = search(h3,code[asmindex].var1);
					if(read != NULL){/////ȫ��
					    AddTable* readtemp=read;////getvalueofarray������ı�readָ��
                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen){/////��ͨȫ�ֱ���
                                asmout<<"\tmov\teax,\t_"<<code[asmindex].var1<<endl;
                            }
                            else {////����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                            getvalueofarry(valueofarry);
                            for(;i<templen;i++)
                                temp[i]='\0';
                            strcpy(code[asmindex].var1,temp);
                            int d=findarraybase(temp);
                            if(d==-1)
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var1<<"+4*ecx]"<<endl;
                            else{
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                              }
                            }

                            temptype=readtemp->type;

					}
					else{//////���Ҳ�����Ҫô�ǳ�����Ҫô��change[$0]

                        int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                        if(i==templen)/////����// mov	6	a�����
                        {
                        if(code[asmindex].var1[0]>='0'&&code[asmindex].var1[0]<='9')
                        {
                            asmout<<"\tmov\teax,\t"<<code[asmindex].var1<<endl;
                            }
                        else
						{
						    asmout<<"\tmov\teax,\t\'"<<code[asmindex].var1<<'\''<<endl;temptype=1;
						    }
                        }
                        else{///change[$0]
                               char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var1,temp);
                            int d=findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                        }

					}

				}
				else////��ʱ����
				{
					asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
					temptype=read->type;
				}
			}
			else///�ֲ�����
			{
			    asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
			    temptype=read->type;
			}

			// �ڶ���ָ��ٰѼĴ����е����ݷŵ���3����������
			read = search(h1,code[asmindex].var3);
			if(read == NULL)
			{
				read = search(h2,code[asmindex].var3);
				if(read == NULL)
				{
					read = search(h3,code[asmindex].var3);
					if(read != NULL)  // Ӧ����read ��Ϊ�յġ���Ȼ���д����
						 {

                          if(strcmp(code[asmindex].var2," ")!=0)///////ȫ�ֶ��������
                          {

                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            for(;i<templen;i++)
                                temp[i]='\0';
                             getvalueofarry(code[asmindex].var2);
                            strcpy(code[asmindex].var3,temp);
                            int d=findarraybase(temp);
                            if(d==-1)
                            asmout<<"\tmov\tdword ptr["<<code[asmindex].var3<<"+4*ecx] "<<",eax"<<endl;
                            else{
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\tdword ptr[ebp+"<<d<<"+4*ecx] "<<",eax"<<endl;
                            }

                        }
						   else ///��ͨȫ�ֱ���
						      asmout<<"\tmov\t_"<<code[asmindex].var3<<",\teax"<<endl;
						      //read->type=temptype;
                    }
					else if(read == NULL)// ��������ʱ�����������ɵģ���Ҫ��������ռ䡣Ӧ���ǲ�Ϊ�յģ�Ϊ�˴��밲ȫ��
                        /////change[$0]�����Ҳ������
						{
                           if(strcmp(code[asmindex].var2," ")!=0)///////ȫ�ֶ��������
                            {
                            int templen;
                            int i;
                            char temp[30];

                            //strcpy(code[asmindex].var2,temp);

                            strcpy(temp,code[asmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                for(;i<templen;i++)
                                temp[i]='\0';
                            getvalueofarry(valueofarry);
                            strcpy(code[asmindex].var3,temp);
                            int d=findarraybase(temp);
                            if(d==-1)
                            asmout<<"\tmov\tdword ptr["<<code[asmindex].var3<<"+4*ecx] "<<",eax"<<endl;
                            else{
                                asmout<<"\t neg ecx"<<endl;
                                asmout<<"\tmov\tdword ptr[ebp+("<<d<<")+4*ecx] "<<",eax"<<endl;
                            }

                        }

						    else{/////�����ɵ���ʱ����

							tp1 = (AddTable*)malloc(sizeof(AddTable));
							tp1->add = (-1)*4*(++counter);
							strcpy(tp1->id,code[asmindex].var3);
							tp1->next = NULL;
							tp1->type=temptype;
							asmout<<"\tmov\tdword  ptr [ebp+("<<tp1->add<<")],\teax"<<endl;/////��ʱ���������ڴ��С�������������
                            asmout<<"\tmov   ecx,ebp"<<endl;
                            asmout<<"\tadd   ecx,"<<tp1->add<<endl;
                            asmout<<"\tcmp   esp ,ecx"<<endl;
                            asmout<<"\tjle  labn"<<templabnumber<<endl;
                            asmout<<"\tmov esp, ecx"<<endl;
                            asmout<<"lab"<<templab<<templabnumber<<":"<<endl;////////֮������ôд��Ϊ���Ǳ�֤ѭ����ʱ����ʱ����ֻ��pushһ��.
                            templabnumber++;
							if(h2 == NULL)
							{
								h2 = tp1;
								he2 = tp1;
							}
							else
							{
								he2->next = tp1;
								he2 = he2->next;
							}
                          }
						}
				}
				else///��ʱ����
				{
					asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
					read->type=temptype;
				}
			}
			else///�ֲ�����
			{
				asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
				//read->type=temptype;
			}
		}


		else if(strcmp(code[asmindex].op,"ret") == 0)  // ����
		{
			//retFlag = 1;
			if(strcmp(code[asmindex].var3," ") != 0)  // return some value.
			{
				read = search(h1,code[asmindex].var3);
				if(read != NULL) // ����Ǿֲ�����
				{
					asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
                    //asmout<<"\tadd\tesp,\t"<<4*counter<<endl;
                    asmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
					popreg();
					asmout<<"\tret"<<endl;
					//read->type=functiontype;
				}
				else
				{
					read = search(h2,code[asmindex].var3);
					if(read != NULL)            // ������ʱ����
					{
						asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
						//asmout<<"\tadd\tesp,\t"<<4*counter<<endl;
						asmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
						popreg();
						asmout<<"\tret"<<endl;
						read->type=functiontype;
					}
					else////ȫ��
					{
					    read =  search(h3,code[asmindex].var3);
					    if(read==NULL)
					    asmout<<"\tmov\teax,\t"<<code[asmindex].var3<<endl;
                        else
						 {
						     asmout<<"\tmov\teax,\t_"<<code[asmindex].var3<<endl;
						     //read->type=functiontype;
						     }
						//asmout<<"\tadd\tesp,\t"<<4*counter<<endl;
						asmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
						popreg();
                        asmout<<"\tret"<<endl;
					}
				}
			}
			else////return ;
			{
				        //asmout<<"\tadd\tesp,\t"<<4*counter<<endl;
				        asmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
						popreg();
						asmindex22=asmindex+1;
						if(!(strcmp(code[asmindex22].op,"end")==0&&strcmp(code[asmindex22].var3,"main")==0))
                        asmout<<"\tret"<<endl;
			}
			   functiontype=-1;////��������Ѻ����ķ�����������һ��

			asmindex++;
			if(strcmp(code[asmindex].op,"end") == 0)
			{
			    counter = 0;						// �����������ü�����Ϊ0
                Destroy(h1);                        //�������ڵľֲ��������Լ���ʱ������ȫ�����
			    h1 = NULL;
			    Destroy(h2);
                h2 = NULL;
                if(strcmp(code[asmindex].var3,"main") == 0)
                     continue;//�����main�Ļ�ֱ�Ӽ���,����������һ��end��䡭����Ԫʽ��Ƶ���©
				asmout<<'_'<<function<<"\tendp"<<endl;
				asmindex++;
				continue;
			}
		}

        ///sma,seq,lar,leq,neq,eql����ת�����;
      else if(strcmp(code[asmindex].op,"sma") == 0||strcmp(code[asmindex].op,"seq") == 0||strcmp(code[asmindex].op,"lar") == 0||
                strcmp(code[asmindex].op,"leq") == 0 ||strcmp(code[asmindex].op,"neq") == 0 ||strcmp(code[asmindex].op,"eql") == 0 )  // ���Ƚϵ�
		{
			read = search(h1,code[asmindex].var2);   // the second argument
			if(read == NULL)
			{
				read = search(h2,code[asmindex].var2);
				if(read == NULL)
				{
				    read=search(h3,code[asmindex].var2);
				    if(read==NULL){////��������change[$0]�����
                        int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                        if(i==templen)/////����
                        {
                        if(code[asmindex].var2[0]>='0'&&code[asmindex].var2[0]<='9')
                        asmout<<"\tmov\tebx,\t"<<code[asmindex].var2<<endl;
                        else
                        asmout<<"\tmov\tebx,\t\'"<<code[asmindex].var2<<"\'"<<endl;
                        }
                        else{///change[$0]
                               char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var2,temp);
                            int d=findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            asmout<<"\tmov\tebx,\tdword ptr["<<code[asmindex].var2<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\tebx,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                        }
				    }

					else{/////ȫ�ֱ���
                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                                asmout<<"\tmov\tebx,\t_"<<code[asmindex].var2<<endl;
                            else{///����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var2,temp);
                            int d=findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            asmout<<"\tmov\tebx,\tdword ptr["<<code[asmindex].var2<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\tebx,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                        }
					}

				}
				else
				{
					asmout<<"\tmov\tebx,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
				}
			}
			else
			{
				asmout<<"\tmov\tebx,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
			}
              //////////��һ��
			read = search(h1,code[asmindex].var1);
			if(read == NULL)
			{
				read = search(h2,code[asmindex].var1);
				if(read == NULL)
				{
				    read=search(h3,code[asmindex].var1);
				    if(read==NULL){////��������change[$0]
                           int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                        if(i==templen)/////����
                        {
                        if(code[asmindex].var1[0]>='0'&&code[asmindex].var1[0]<='9')
                        asmout<<"\tmov\teax,\t"<<code[asmindex].var1<<endl;
                        else
                        asmout<<"\tmov\teax,\t\'"<<code[asmindex].var1<<"\'"<<endl;
                        }
                       else {
                               char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var1,temp);
                            int d=findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                       }
				    }

					else{/////ȫ�ֱ���
                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            asmout<<"\tmov\teax,\t_"<<code[asmindex].var1<<endl;
                            else{/////����ȫ�ֱ���
                                 char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(code[asmindex].var1,temp);
                            int d=findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                        }
					}


				}
				else
				{
					asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
				}
			}
			else
			{
				asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
			}

			asmout<<"\tcmp\teax,\tebx"<<endl;///�����Ƚ�
			if(strcmp(code[asmindex].op,"sma") == 0){
                asmout<<"\tjnge\t"<<code[asmindex].var3<<endl;
			}

			if(strcmp(code[asmindex].op,"seq") == 0){
                asmout<<"\tjle\t"<<code[asmindex].var3<<endl;
			}

			if(strcmp(code[asmindex].op,"lar") == 0){
                asmout<<"\tjnle\t"<<code[asmindex].var3<<endl;
			}

			if(strcmp(code[asmindex].op,"leq") == 0){
                asmout<<"\tjge\t"<<code[asmindex].var3<<endl;
			}
			if(strcmp(code[asmindex].op,"eql") == 0){
                asmout<<"\tjz\t"<<code[asmindex].var3<<endl;
			}
			if(strcmp(code[asmindex].op,"neq") == 0){
                asmout<<"\tjnz\t"<<code[asmindex].var3<<endl;
			}
		}

        else if(strcmp(code[asmindex].op,"jmp") == 0){
            asmout<<"\tjmp\t"<<code[asmindex].var3<<endl;
        }
        else if(strcmp(code[asmindex].op,"opp") == 0){////ȡ������
            int temptype=0;
            read = search(h1,code[asmindex].var1);//////��һ��ԭ�������Ƿ��Ǿֲ�����
			if(read == NULL)
			{
				read = search(h2,code[asmindex].var1);/////�Ƿ���ʱ����
				if(read == NULL)
				{
				    read = search(h3,code[asmindex].var1);
				   if(read ==NULL)
				      asmout<<"\tmov\teax,\t"<<code[asmindex].var1<<endl;
                    else
                    {
                        //ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                read=search(h3,code[asmindex].var1);
                                if(read==NULL)
                                asmout<<"\tmov\teax,\t"<<code[asmindex].var1<<endl;
                                else{
                                    asmout<<"\tmov\teax,\t_"<<code[asmindex].var1<<endl;
                                    temptype=read->type;
                                }

                            }
                            else {////����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                read=search(h3,code[asmindex].var1);
                                temptype=read->type;
                                for(;i<templen;i++)
                                temp[i]='\0';
                            strcpy(code[asmindex].var1,temp);
                            int d=findarraybase(temp);
                            if(d==-1)
                            asmout<<"\tmov\teax,\tdword ptr["<<code[asmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                asmout<<"\t neg ecx"<<endl;
                                asmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx]"<<endl;
                            }

                            }

                        asmout<<"\tmov\teax,\t_"<<code[asmindex].var1<<endl;
                        temptype=read->type;
                    }
				}
				else////����ʱ����
				{
                    asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
                    temptype=read->type;
				}
			}
			else ////�Ǿֲ�����
			{
				asmout<<"\tmov\teax,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
                   temptype=read->type;
			}
			asmout<<"\tneg\teax"<<endl;///ȡ��
			// ���������������ֵ

			read = search(h1,code[asmindex].var3);
			if(read == NULL)///��ʱ����
			{
				read = search(h2,code[asmindex].var3);////����ʱ�������в���
				if(read == NULL)///��ʱ���������Ҳ���
				{
					read = search(h3,code[asmindex].var3);///��Ҫ�ǲ���ȫ�ֵı���
					if(read == NULL)   // ������Ҳ�����˵�����Ǹ��µ���ʱ����
					{
						tp1 = (AddTable *)malloc(sizeof(AddTable));
						strcpy(tp1->id,code[asmindex].var3);
						tp1->add = (-4)*(++counter) ;
						tp1->next = NULL;
                        tp1->type=temptype;
						if(h2 == NULL)///�������ʱ�������ڷ�����ʱ����������
						{
							h2 = tp1;
							he2 = tp1;
						}
						else
						{
							he2->next = tp1;
							he2 = he2->next;
						}
                          asmout<<'\t'<<"push\teax"<<endl;/////��ʱ���������ڴ��С�������������
					}
					else				//Ϊȫ�ֱ���
					      {
					        int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,code[asmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                read=search(h3,code[asmindex].var3);
                                if(read==NULL)
                                asmout<<"\tmov "<<code[asmindex].var3<<",\teax"<<endl;
                                else{
                                 asmout<<"\tmov _"<<code[asmindex].var3<<",\teax"<<endl;
                                }

                            }
                            else {////����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                            strcpy(code[asmindex].var1,temp);
                            int d=findarraybase(temp);
                            if(d==-1)
                            asmout<<"\tmov dword ptr["<<code[asmindex].var3<<"+4*ecx]"<<",\teax"<<endl;
                            else
                            {
                                asmout<<"\tneg ecx"<<endl;
                                asmout<<"\tmov dword ptr[ebp+("<<d<<")+4*ecx]"<<",\teax"<<endl;
                            }

                            }

                        //asmout<<"\tmov _"<<code[asmindex].var3<<",\teax"<<endl;
						//read->type=temptype;

				      }
				}
				else////��ʱ����
				{
					asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
					read->type=temptype;
				}
			}
			else////�ֲ�����
			{
				asmout<<"\tmov\tdword  ptr [ebp+("<<read->add<<")],\teax"<<endl;
				//read->type=temptype;
			}
		 }


     asmindex++;
  }
      asmout<<"; Դ�������"<<endl;
      asmout.close();

}

void popreg(){
    asmout<<";-------------�ָ��Ĵ���-----------"<<endl;
	asmout<<'\t'<<"pop"<<'\t'<<"ebp"<<endl;
	//asmout<<'\t'<<"pop"<<'\t'<<"ebx"<<endl;
	asmout<<'\t'<<"pop"<<'\t'<<"edi"<<endl;
	asmout<<'\t'<<"pop"<<'\t'<<"esi"<<endl;
	asmout<<'\t'<<"pop"<<'\t'<<"edx"<<endl;
	asmout<<'\t'<<"pop"<<'\t'<<"ecx"<<endl;
	asmout<<'\t'<<"pop"<<'\t'<<"ebx"<<endl;
}


AddTable* search(AddTable * head, char *id)
{
	AddTable *t = head;
	while(t != NULL)
	{
		if(strcmp(t->id,id) == 0)
			return t;
		t = t->next;
	}

	return NULL;
}
void Destroy(AddTable* head)
{
	if(head == NULL)
		return;
	else
	{
		Destroy(head->next);
		free(head);
	}
}

void getvalueofarry(char *s){

    // ��һ��ָ��ѵ�1���������ŵ��Ĵ�����
            char name[30];
            strcpy(name,s);
			read = search(h1,name);
			if(read == NULL)
			{
				read =search(h2,name);
				if(read == NULL)
				{
					read = search(h3,name);
					if(read != NULL){/////ȫ�ֻ��߳���

                            asmout<<"\tmov\tecx,\t_"<<name<<endl;

					}
					else
                         // mov	i 	6�����
						asmout<<"\tmov\tecx,\t"<<name<<endl;
				}
				else////��ʱ����
				{
					asmout<<"\tmov\tecx,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
				}
			}
			else///�ֲ�����
			{
			    asmout<<"\tmov\tecx,\tdword  ptr [ebp+("<<read->add<<")]"<<endl;
			}


    /////ecx�ݴ�valueofarray
}
int findarraybase(char* s){////�����ҵ��ֲ�����ı����Ļ���ַ.change[0]��λ��
      char name[30];
      strcpy(name,s);
      strcat(name,"[0]");
      read = search(h1,name);
      if(read!=NULL)
      {
          return read->add;
      }
      else return -1;////�Ҳ����Ļ�˵���Ǹ�ȫ�ֶ��������


}
