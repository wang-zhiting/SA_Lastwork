int main(){
    int i=0;
    int n=1;
    switch(n){
        case 1:{i=n+n;break;}
        case 5:i=i+n*n;
    }
}