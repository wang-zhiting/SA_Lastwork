#ifndef ASM_H_INCLUDED
#define ASM_H_INCLUDED



#endif //ASM_H_INCLUDED
typedef struct _addTable
{
	char id[20];//名称
	int add;//相对基址的偏移量（其实就是表看做数组后的索引i）
	int type;////1 char 0 int
	struct _addTable *next;
}AddTable;/////为了在生成变量中查找到相对地址
