int main(){
    int i=0;
    int n=1;
    switch(n){
        case 1:{i=n+n;i=i+5;}
        case 5:i=i+n*n;
    }
}