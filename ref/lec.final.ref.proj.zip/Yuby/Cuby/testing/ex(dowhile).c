int main()
{
    int n=2;
    do{
        n++;
    }while(n<0);
}