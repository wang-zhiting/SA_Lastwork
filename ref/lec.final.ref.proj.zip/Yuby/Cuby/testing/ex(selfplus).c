// int main(){
//     int n;
//     int a;
//     int t;
//     t = 5;
//     n = 1;
//     a = n ++;
//     t = a ++;
// }
int main(){
    int n;
    int a;
    n = 2;
    a = ++n;
    a = n++;
}