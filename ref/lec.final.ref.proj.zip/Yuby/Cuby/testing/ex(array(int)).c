int main(){

    int a = 10;
    int b[10];

    int i;
    // for(i = 0; i < 10; ++i){
    //     b[i] = i;
    // }

    // for(i = 0; i < 10; ++i){
    //     print b[i];
    // }
    a[0] = 1;

}