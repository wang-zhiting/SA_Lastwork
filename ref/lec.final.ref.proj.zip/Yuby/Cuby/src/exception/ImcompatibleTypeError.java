package exception;

public class ImcompatibleTypeError extends Exception {
    public ImcompatibleTypeError(String msg){
        super(msg);
    }
}
