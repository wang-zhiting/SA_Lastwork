int main()
{
    try{
        int a=0;
        int n=5;
        n=n/a;
    }
    catch("ArithmeticalExcption")
    {
        n=0;
        print n;
    }   
}