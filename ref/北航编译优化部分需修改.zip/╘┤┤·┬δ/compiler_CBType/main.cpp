

#include "stdafx.h"

#include "define.h"
#include "error.h"
#include "tempprint.h"
#include <iostream>
#include <cstring>
using namespace std;

const int      norw = 10;         // { no. of reserved words }
const int      txmax = 100;        //{ length of identifier table }
const int      nmax = 14;          //{ max. no. of digits in numbers }
const int      al = 10;            //{ length of identifiers }
const int      amax = 2047;        //{ maximum address }
const int      levmax = 3;         //{ maximum depth of block nesting }
const int      cxmax = 200;        //{ size of code array }


char tempc;  ////ch
int symbol=-1;//    { last symbol read }
char id[30] ;///     { last identifier read }
int   number;   ///{ last number read }
//int   cc=0;   ///{ character count }
//int   ll=0 ;//  { line length }
int   err=0;   /// {*kk : last identifier length�� err����������� *}
int linenumer=0;   //////�к�


char tokenbuf[82]={0}; ///{*������ַ�������������Ϊ81*}
int tokenbufpoint=0;
int MinusOrIntegerflag=-1;///��ʾ�Ǹ��Ż�������

info Table[100];/////���ű�
middlecode code[1000];


string a;

int temphwk1number=0;

FILE* fin;
FILE* fout;
string filename;
//int cx ;   //{ code allocation index } {*code������*}
#ifdef DEBUG
int cx=0;
#else
  int cx;
#endif

extern void procedure();
extern void printmidcode();
extern void toasm();
extern void optimize();
extern void tooptiasm();

void error(int e){
	//fprintf(fout,"error %d: ��%d��:%s\n",e,linenumer,errorde[e].c_str());
	printf("error %d: ��%d��:%s\n",e,linenumer,errorde[e].c_str());
	err++;
}



//////�ļ���д����
void open_file(){
	cout<<"input the file name"<<endl;
	cin>>filename;
	fin=fopen(filename.c_str(),"r+");
	fout=fopen("12061025_token.txt","w+");
	if(fin==NULL)
	{ fprintf(fout,"open failed\n"); return;}


}
//////�ļ���д��������



//////�ʷ�����������Ҫ�����к���
void retract(){   ////����ָ�뵹��һ��
   fseek(fin,-1,SEEK_CUR);
}
void cleartonken(){  /////����ַ�������
    int i;
    tempc='\0';
    for(i=0;i<81;i++)
       tokenbuf[i]='\0';
    tokenbufpoint=0;
}

void catToken(){ ////�ַ�����������ַ�

    if(tokenbufpoint<81)
    tokenbuf[tokenbufpoint++]=tempc;
    else
        { fprintf(fout,"%d string is too long!\n",linenumer); return ;}
}

int  reserver(){ ///reserved words judge
     int i=0;

     if(strcmp(tokenbuf,"const")==0)
        i=CONST;
     else if(strcmp(tokenbuf,"int")==0)
        i=INT;
     else if(strcmp(tokenbuf,"void")==0)
        i=VOID;
     else if(strcmp(tokenbuf,"char")==0)
        i=CHAR;
     else if(strcmp(tokenbuf,"main")==0)
        i=MAIN;
     else if(strcmp(tokenbuf,"if")==0)
        i=IF;
	 else if(strcmp(tokenbuf,"else")==0)
	    i=ELSE;
	 else if(strcmp(tokenbuf,"while")==0)
	    i=WHILE;
	 else if(strcmp(tokenbuf,"scanf")==0)
	    i=SCANF;
	 else if(strcmp(tokenbuf,"printf")==0)
	    i=PRINTF;
	 else if(strcmp(tokenbuf,"return")==0)
	    i=RETURN;
	 else if(strcmp(tokenbuf,"switch")==0)
		 i=SWITCH;
	  else if(strcmp(tokenbuf,"case")==0)
		 i=CASE;
     return i;
}

int transnum(){ ////�������ַ�ת��������
    int j=0;
    int num=0;
    for(j=0;j<tokenbufpoint;j++)
       num=num*10+tokenbuf[j]-'0';
    return num;
}
int isLetter(){  /////�ж��Ƿ�����ĸ
    if((tempc>='a'&&tempc<='z')||(tempc>='A'&&tempc<='Z')||tempc=='_')
        {
            if(tempc>='A'&&tempc<='Z')//////��СдͳһΪСд
                tempc='a'+tempc-'A';
            return 1;
        }
    else
        return 0;
    }

int isDigit(){ ////�ж��Ƿ�������
   if((tempc>='0'&&tempc<='9'))
        return 1;
    else
        return 0;
   }

//////�ʷ���������
void getsym(){
    int resultValue;

	cleartonken();
	tempc=fgetc(fin);
	if(linenumer==0)
	{
		if(tempc==EOF)
		{ symbol = EOFSYM; fprintf(fout,"file is nul\n");	return ;}
		else linenumer=1; ////����������ʼֵΪ1
	}

	while(tempc==' '||tempc=='\t'||tempc=='\n')
	{
		if(tempc=='\n')
			linenumer++;////��������
		tempc=fgetc(fin);
		if (tempc==EOF)
		{
			{ symbol = EOFSYM; fprintf(fout,"END OF FILE\n");	return ;}
		}
     }
	if (tempc==EOF)
	{
		{ symbol = EOFSYM; fprintf(fout,"END OF FILE\n");	return ;}
	}
	if(isLetter())
        {
           while(isLetter()||isDigit())
           {
              catToken();
              tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}
           }
           retract();
           resultValue = reserver();

		   if(resultValue==0) {
			   symbol=ident;
			   fprintf(fout,"%d %s %s\n",++temphwk1number,tempprint[symbol].c_str(),tokenbuf);}
		   else {
			   symbol = resultValue;
			   fprintf(fout,"%d %s %s\n",++temphwk1number,tempprint[symbol].c_str(),tokenbuf);}

        }
	else if(isDigit())
     {
         while(isDigit())
            {
              catToken();
              tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}
            }
           if(isLetter()){/////����������123abc�ı�ʶ��
           error(0);
          }
          retract();
          if(tokenbuf[0]=='0'&&tokenbuf[1]!=0)////��������0��ͷ����0123������
             {
                 error(0);
               }

          number = transnum();
#ifdef DEBUG
          fprintf(fout,"number is %d\n",number);

#endif // DEBUG
		  symbol=integer;
		  fprintf(fout,"%d %s %s\n",++temphwk1number,tempprint[symbol].c_str(),tokenbuf);
         }
	else if(tempc=='='){

              tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}

			  if(tempc=='=') {symbol=EQUAL;fprintf(fout,"%d %s ==\n",++temphwk1number,tempprint[symbol].c_str());}
			  else {retract(); symbol =ASSIGN;fprintf(fout,"%d %s =\n",++temphwk1number,tempprint[symbol].c_str());}

        }
	else if(tempc=='<'){

              tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}

			  if(tempc=='=') {symbol=SMALLER_EQUAL;fprintf(fout,"%d %s <=\n",++temphwk1number,tempprint[symbol].c_str());}
			  else {retract(); symbol =SMALLER;fprintf(fout,"%d %s <\n",++temphwk1number,tempprint[symbol].c_str());}

        }
	else if(tempc=='>'){

              tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}

			  if(tempc=='=') {symbol=LARGER_EQUAL;fprintf(fout,"%d %s >=\n",++temphwk1number,tempprint[symbol].c_str());}
			  else {retract(); symbol =LARGER;fprintf(fout,"%d %s >\n",++temphwk1number,tempprint[symbol].c_str());}

        }
	else if(tempc=='!'){

              tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}

			  if(tempc=='=') {symbol=NOT_EQUAL;fprintf(fout,"%d %s !=\n",++temphwk1number,tempprint[symbol].c_str());}
			  else {retract(); error(2);}

        }
	else if (tempc=='\'')
	{
		tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}
              if(tempc=='+'||tempc=='-'||tempc=='*'||tempc=='/'||tempc=='_'||(tempc>='a'&&tempc<='z')||
                 (tempc>='A'&&tempc<='Z')||isDigit())
			  catToken();//////�����character����characterһ������tokenbuf����

              else {error(1);}

	    tempc=fgetc(fin);

		if(tempc!='\'')
		{
			error(3);
		}
		else {symbol=character;fprintf(fout,"%d %s %s\n",++temphwk1number,tempprint[symbol].c_str(),tokenbuf);}
	}
	else if(tempc=='\"')
	{
		tempc=fgetc(fin);
              if(tempc==EOF)
              { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}
			  while (tempc!='\"'&&tempc!=EOF)
			  {
			      if((tempc!=33&&tempc!=32&&tempc<35)||tempc>126)
                  {
                      printf("%c\n",tempc);
                      error(0);
                      break;
                  }
				  catToken();
				  tempc=fgetc(fin);
				  if (tokenbufpoint>=60)
				  {
					  error(4);
					  do
					  {
						   tempc=fgetc(fin);
                           if(tempc==EOF)
                          { symbol = EOFSYM;fprintf(fout,"EOF!\n");return ;}
					  } while (tempc!=' '&&tempc!='\n'&&tempc!='	');
					  break;
				  }
			  }
			  symbol=chstring;fprintf(fout,"%d %s %s\n",++temphwk1number,tempprint[symbol].c_str(),tokenbuf);

	}
	else if(tempc=='+'){symbol=PLUS;fprintf(fout,"%d %s +\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc=='-') {symbol= MINUS;fprintf(fout,"%d %s -\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc=='*')  {symbol =MUL;fprintf(fout,"%d %s *\n",++temphwk1number,tempprint[symbol].c_str());}
    else if(tempc=='/')  {symbol =DEVIDE;fprintf(fout,"%d %s *\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc=='(')  {symbol = L_BRACKET;fprintf(fout,"%d %s (\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc==')')  {symbol = R_BRACKET;fprintf(fout,"%d %s )\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc=='[') {symbol = L_M_BRACKET;fprintf(fout,"%d %s [\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc==']')  {symbol = R_M_BRACKET;fprintf(fout,"%d %s ]\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc=='{')  {symbol = L_B_BRACKET;fprintf(fout,"%d %s {\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc=='}')  {symbol = R_B_BRACKET;fprintf(fout,"%d %s }\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc==';')  {symbol = SEMICOLON;fprintf(fout,"%d %s ;\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc==',')  {symbol = COMMA;fprintf(fout,"%d %s ,\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc==':')  {symbol = COLON;fprintf(fout,"%d %s ,\n",++temphwk1number,tempprint[symbol].c_str());}
	else if(tempc==' '||tempc=='\t'){return;}
	else if(tempc=='\n'){linenumer++;return;}
	else 	error(0);

}
//////�ʷ�����������Գ���
void testgetsym(){
	tempAssign();
	while (true)
	{
		getsym();
		if (tempc==EOF)
		{
		    symbol = EOFSYM;
			break;
		}
	}
}
///////�ʷ������������





/////============main ����=======
int _tmain(int argc, _TCHAR* argv[])
{
	open_file();
	//testgetsym();
	procedure();
    printmidcode();
    int a;
    cout<<"input 1 for optimize"<<endl;
    cin>>a;
    if(a==1)
    optimize();
    toasm();
    if(a==1)
    tooptiasm();
	return 0;
}

