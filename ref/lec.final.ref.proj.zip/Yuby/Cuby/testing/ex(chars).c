int main ()
{
    char c = 'h';
    print c;

}