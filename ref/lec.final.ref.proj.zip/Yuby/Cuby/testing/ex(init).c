int a = 1;
int b = 2 + 3;

int main(){
    int c = 3;
    print a;
    print b;
    print c;
}