#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include "asm.h"
#include "optimize.h"
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
extern opmiddlecode newcode[1000];/////middle code
extern int newcodelen;

void optiasm_head();
void _datasegment();
void procoptiasm();
void _popreg();
void _getvalueofarry(char *s);
int _findarraybase(char* s);

void _Destroy(AddTable* _head);
AddTable* _search(AddTable * _head, char *id);
//FILE * optiasmin;
int opasmindex=0;
int opasmindex22=0;

int _counter=0;////�ֲ���������ʱ��������
int _varc=0;
int _push = 0;////�����������õ�ʱ�򴫲�(call)

int _functiontype=-1;
char _str[30];////���ú������õ�
char _templab='n';
int _templabnumber=0;



AddTable *_h1 = NULL,*_h2 = NULL,*_h3=NULL,*_tp1,*_he1,*_he2;
/////_h1 �ֲ������ͳ�����ͷ�� _h2  ��ʱ������ͷ��_h3��ȫ�ֳ����ͱ�����ͷ�� ʣ�µ�����ָ�룬tp���������ڴ�ռ䣬
/////heָ��ָ��Ķ��Ǹ���������ĩβ���������������ã�_he1�ڽ���ȫ�ֱ�ʱָ��ȫ�ֱ�β����������ȫ�ֱ�֮��ָ��ֲ���β����
AddTable  *_read;

ofstream optiasmout ("optiasm.asm");
void tooptiasm(){
    optiasm_head();
    optiasmout<<";----------code segment-------"<<endl;
    _datasegment();
    optiasmout<<";datamen over"<<endl;
    procoptiasm();

}
void optiasm_head(){
   optiasmout<<".386"<<endl;
   optiasmout<<".model flat,stdcall"<<endl;
   optiasmout<<"option casemap:none"<<endl;
   optiasmout<<"Include c:\\masm32\\include\\windows.inc"<<endl;
   optiasmout<<"Include c:\\masm32\\include\\kernel32.inc"<<endl;
   optiasmout<<"Include c:\\masm32\\include\\msvcrt.inc"<<endl;
   optiasmout<<"Includelib c:\\masm32\\lib\\msvcrt.lib"<<endl;
   optiasmout<<"Includelib c:\\masm32\\lib\\kernel32.lib"<<endl;
   optiasmout<<"Include c:\\masm32\\macros\\macros.asm"<<endl;

}

void _datasegment(){//////ȫ�����ݶ�
    optiasmout<<".data"<<endl;
   // optiasmout<<"_temp_for_print dword ?"<<endl;
   while (strcmp(newcode[opasmindex].op,"const")==0) {////ȫ�ֳ�������
       int temptype=0;
        if (strcmp(newcode[opasmindex].var1,"int")==0)
            { optiasmout<<"\t_"<<newcode[opasmindex].var3<<'\t'<<"equ"<<'\t'<<newcode[opasmindex].var2<<endl; temptype=0;}
		else
			{ optiasmout<<"\t_"<<newcode[opasmindex].var3<<'\t'<<"equ"<<'\t'<<"\'"<<newcode[opasmindex].var2<<"\'"<<endl;temptype=1;}
		_tp1 = (AddTable*)malloc(sizeof(AddTable));////_h3��ȫ�ֳ��������ı�ͷ
		strcpy(_tp1->id,newcode[opasmindex].var3);
		_tp1->add = 0;
		_tp1->next = NULL;
        _tp1->type=temptype;
		if(_h3 == NULL)////_he1����������������
		{
			_h3 = _tp1;
			_he1 = _tp1;
		}
		else
		{
			_he1->next = _tp1;
			_he1 = _he1->next;
		}
		opasmindex++;
	}
	while(strcmp(newcode[opasmindex].op,"int")==0|| strcmp(newcode[opasmindex].op,"char")==0)
	   {    /////ȫ�ֱ�������
	      if(strcmp(newcode[opasmindex].var2," ")!=0){/////����ȫ�ֱ�������,��һ���ԡ���
                int valueofarray = atoi(newcode[opasmindex].var2);
                char temp_1[20];
                strcpy(temp_1,newcode[opasmindex].var3);
                optiasmout<<'\t'<<temp_1<<'\t'<<"DWORD"<<'\t'<<valueofarray<<" DUP(?)"<<endl;
                for(int i=0;i<valueofarray;i++){
                      char number_of_array[20];
                      char temp_2[20];
                      strcpy(temp_2,temp_1);
                      itoa(i,number_of_array,10);
                      strcat(temp_2,"[");
                      strcat(temp_2,number_of_array);
                      strcat(temp_2,"]");
                      _tp1 = (AddTable*)malloc(sizeof(AddTable));
                      _tp1->add = 0;////_counter�Ǿֲ������ļ�������ǰ���Ǹ�����ΪX86��ջ��ַ����������������ջ���ǵ͵�ַ����ebp+���λ�Ʋ��ǵ�ַ
			          _tp1->next = NULL;

			           if(strcmp(newcode[opasmindex].op,"int")==0)
                       _tp1->type=0;

                       if(strcmp(newcode[opasmindex].op,"char")==0)
                        _tp1->type=1;

                      strcpy(_tp1->id,temp_2);/////change[0],change[1],change[2],change[3]������������

			          if(_h3 == NULL)////_he1����������������
		               {
			              _h3 = _tp1;
			              _he1 = _tp1;
		                }
		               else
		               {
			              _he1->next = _tp1;
			              _he1 = _he1->next;
		                }
                     }
			    }
	    else {/////��ͨȫ�ֱ���
		optiasmout<<"\t_"<<newcode[opasmindex].var3<<'\t'<<"dword"<<'\t'<<"?"<<endl;
        _tp1 = (AddTable*)malloc(sizeof(AddTable));////_h3��ȫ�ֳ��������ı�ͷ
		strcpy(_tp1->id,newcode[opasmindex].var3);
		_tp1->add = 0;
		_tp1->next = NULL;

         if(strcmp(newcode[opasmindex].op,"int")==0)
         _tp1->type=0;

         if(strcmp(newcode[opasmindex].op,"char")==0)
         _tp1->type=1;

		if(_h3 == NULL)////_he1����������������
		{
			_h3 = _tp1;
			_he1 = _tp1;
		}
		else
		{
			_he1->next = _tp1;
			_he1 = _he1->next;
		}
      }
		opasmindex++;
	}
    optiasmout<<endl;
}



void procoptiasm(){
    char function[20];
    optiasmout<<"z dword  50 dup(?)"<<endl;//////�������ݶκ�invoke�������ʽ�洢��ͻ�������������Բŷ��֡�
    optiasmout<<";-----------CODE SEGMENT"<<endl;
    optiasmout<<".CODE"<<endl;

    while(opasmindex<newcodelen){
            //���
       if(strcmp(newcode[opasmindex].op,"setlab")==0){
                optiasmout<<newcode[opasmindex].var3<<":"<<endl;
             }
       else if(strcmp(newcode[opasmindex].op,"start")==0&&(strcmp(newcode[opasmindex].var3,"main")!=0)){////һ���Ӻ���
          _counter=0;
          _varc=0;
          opasmindex22 = opasmindex+1;
          if(strcmp(newcode[opasmindex].var1,"char")==0)
            _functiontype=1;
          if(strcmp(newcode[opasmindex].var1,"int")==0)
            _functiontype=0;
          if(strcmp(newcode[opasmindex].var1,"void")==0)
            _functiontype=2;
          optiasmout<<'_'<<newcode[opasmindex].var3<<'\t'<<"PROC"<<endl;
          ///get1s PROC  NEAR32
          while(strcmp(newcode[opasmindex22].op,"para")==0){/////ͳ�Ʋ������������洦���βλ��õ�_varc
              _varc++;
             // optiasmout<<newcode[opasmindex22].var3<<":dword";
              opasmindex22++;
             // if(strcmp(newcode[opasmindex22].op,"para")==0)////��������βδ�ӡ,����س�
               // optiasmout<<',';
              //  else optiasmout<<endl;
              }
            strcpy(function,newcode[opasmindex].var3);

            optiasmout<<";-------------------�����ֳ�---------"<<endl;
            optiasmout<<'\t'<<"push"<<'\t'<<"ebx"<<endl;
			optiasmout<<'\t'<<"push"<<'\t'<<"ecx"<<endl;
			optiasmout<<'\t'<<"push"<<'\t'<<"edx"<<endl;
			optiasmout<<'\t'<<"push"<<'\t'<<"esi"<<endl;
			optiasmout<<'\t'<<"push"<<'\t'<<"edi"<<endl;
            optiasmout<<'\t'<<"push"<<'\t'<<"ebp"<<endl;/// push	ebp/////���ú�����ebp��֮ǰ��һ����retadress
            optiasmout<<'\t'<<"mov"<<'\t'<<"ebp,"<<'\t'<<"esp"<<endl; /// mov	ebp,	esp  EBPָ����ǵ�ǰ�����Ļ���ַ
            optiasmout<<";-------------------�����ֳ�����---------"<<endl;
			///Ȼ���ǰѴ����ֵ�;ֲ������ٽ�һ������������<-->��ַ����ԣ�������ΪEBP+,�ֲ�����ΪEBP-
			/// �Ժ��������ʱ���������������Ҫ�Ļ�����ѹջ��������
          }

      else if(strcmp(newcode[opasmindex].op,"start") == 0 && strcmp(newcode[opasmindex].var3,"main") == 0)   // the main function
		{
			optiasmout<<"START:"<<endl;
			optiasmout<<'\t'<<"push"<<'\t'<<"ebp"<<endl;
			optiasmout<<'\t'<<"mov"<<'\t'<<"ebp,"<<'\t'<<"esp"<<endl;
			strcpy(function,"main");
			_counter = 0;
		}
		///TODO:
      else if(strcmp(newcode[opasmindex].op,"end")==0&&strcmp(newcode[opasmindex].var3,"main")!=0){////��������
            //optiasmout<<'\t'<<"add"<<'\t'<<"esp,"<<'\t'<<4*_counter<<endl;
            optiasmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
			_popreg();					 	// �˳��Ĵ���
            optiasmout<<'\t'<<"ret"<<endl;
			_counter = 0;						// �����������ü�����Ϊ0
            _Destroy(_h1);                        //�������ڵľֲ��������Լ���ʱ������ȫ�����
			_h1 = NULL;
			_Destroy(_h2);
			_h2 = NULL;
			optiasmout<<'_'<<function<<"\tendp"<<endl;
      }
      else if(strcmp(newcode[opasmindex].op,"end") == 0  && strcmp(function,"main") == 0){/////main ��������

			optiasmout<<'\t'<<"pop"<<'\t'<<"ebp"<<endl;
			optiasmout<<"   invoke ExitProcess, 0; exit with newcode 0"<<endl;
			optiasmout<<"END START"<<endl;
			_h1 = NULL;
			_h2 = NULL;
            _counter = 0;
          }
      else if(strcmp(newcode[opasmindex].op,"parav") == 0)		// ��������ʱ��ֵ  push vparameter,���������д�ڴ�?
		{
			_push ++;
			_read = _search(_h1,newcode[opasmindex].var3);			// ���Ҫ��ѭһ����ԭ���ȵ�����ֲ�����(���������β�Ҳ��ֲ�����)�����ҡ�
			if(_read == NULL)                    // ȥ��ʱ�����ҡ�
			{
				_read = _search(_h2,newcode[opasmindex].var3);
				if(_read == NULL)                // ���û�ҵ���Ҫô��const���͵ģ�Ҫô���ǳ���,����ֱ�������Ϊ����
				{
                    _read=_search(_h3,newcode[opasmindex].var3);
                    if(_read==NULL){/////���Ҳ�����Ҫô�Ǹ�������Ҫô�Ǹ��������
                         //ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////����
                            {
                                if(newcode[opasmindex].var3[0]>='0'&&newcode[opasmindex].var3[0]<='9')
                                optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var3<<endl;
                                else
                                optiasmout<<"\tmov\teax,\t\'"<<newcode[opasmindex].var3<<"\'"<<endl;
                            }
                            else {////����
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(newcode[opasmindex].var3,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)
                            optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var3<<"+4*ecx]"<<endl;
                            else
                            {
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }

                        }

                    }

					else////��ȫ�ֱ���
                    {
                        int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var3<<endl;
                            }
                            else {////����
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(newcode[opasmindex].var3,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var3<<"+4*ecx]"<<endl;
                            else
                            {
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                     }

                    }


					optiasmout<<"\t;to pass values to the function"<<endl;
					optiasmout<<"\tpush\teax"<<endl;////����ѹջ
				}
				else////����ʱ�����������ҵ���
				{
                    optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
					optiasmout<<"\t;to pass values to the function"<<endl;
					optiasmout<<"\tpush\teax"<<endl;//����ѹջ
				}
			}
			else////�ھֲ����������ҵ���
			{
				    optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
					optiasmout<<"\t;to pass values to the function"<<endl;
					optiasmout<<"\tpush\teax"<<endl;//����ѹջ
			}
		}
		else if(strcmp(newcode[opasmindex].op,"int")==0||strcmp(newcode[opasmindex].op,"char")==0){/////�ֲ�����,��Ϊȫ�ֱ����Ѿ�Ū���ˡ���

			if(strcmp(newcode[opasmindex].var2," ")!=0){/////�������Ҫ������������ַ
                int valueofarray = atoi(newcode[opasmindex].var2);
                char temp_1[20];
                strcpy(temp_1,newcode[opasmindex].var3);
                for(int i=0;i<valueofarray;i++){
                      char number_of_array[20];
                      char temp_2[20];
                      strcpy(temp_2,temp_1);
                      itoa(i,number_of_array,10);
                      strcat(temp_2,"[");
                      strcat(temp_2,number_of_array);
                      strcat(temp_2,"]");
                      _tp1 = (AddTable*)malloc(sizeof(AddTable));
                      _tp1->add = (-1)*4*(++_counter);////_counter�Ǿֲ������ļ�������ǰ���Ǹ�����ΪX86��ջ��ַ����������������ջ���ǵ͵�ַ����ebp+���λ�Ʋ��ǵ�ַ
			          _tp1->next = NULL;
			          if(strcmp(newcode[opasmindex].op,"char")==0)
                        _tp1->type=1;
			          if(strcmp(newcode[opasmindex].op,"int")==0)
                        _tp1->type=0;

                      strcpy(_tp1->id,temp_2);/////change[0],change[1],change[2],change[3]������������
                      optiasmout<<"\tmov\teax,\t"<<'0'<<";Define Local Variables"<<endl;////������ֵĬ��Ϊ0
			          optiasmout<<"\tpush\teax"<<endl;////�ֲ�����ѹջ
			          if(_h1 == NULL)                                                // �����ֲ����ű���
			           {
				       _h1 = _tp1;
				       _he1 = _tp1;
			           }
			           else
			           {
				       _he1->next = _tp1;
				       _he1 = _he1->next;
			             }
                        }
			    }
			else {///�ֲ���������
              _tp1 = (AddTable*)malloc(sizeof(AddTable));
              _tp1->add = (-1)*4*(++_counter);/////������:_counter�Ǿֲ������ļ�������Ϊʲôǰ���Ǹ��ţ���ΪX86��ջ��ַ��������������ջ���ǵ͵�ַ����
			  _tp1->next = NULL;
			  if(strcmp(newcode[opasmindex].op,"char")==0)
                        _tp1->type=1;
              if(strcmp(newcode[opasmindex].op,"int")==0)
                        _tp1->type=0;

              strcpy(_tp1->id,newcode[opasmindex].var3);
              optiasmout<<"\tmov\teax,\t"<<'0'<<";Define Local Variables"<<endl;///������ֵĬ��Ϊ0
			  optiasmout<<"\tpush\teax"<<endl;
			  if(_h1 == NULL)                                                // �����ֲ����ű���
			  {
				_h1 = _tp1;
				_he1 = _tp1;
			  }
			  else
			  {
				_he1->next = _tp1;
				_he1 = _he1->next;
			  }
			}
         }
         else if(strcmp(newcode[opasmindex].op,"const")==0)////�ֲ���������
            {
                int temptype=0;
                if (strcmp(newcode[opasmindex].var1,"int")==0)
                {
                    optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var2<<";Define Local Const Variables"<<endl;///
                    temptype=0;
                    }
		          else
			    {
			        optiasmout<<"\tmov\teax,\t\'"<<newcode[opasmindex].var2<<"\';Define Local Const Variables"<<endl;///
			        temptype=1;
			        }
              _tp1 = (AddTable*)malloc(sizeof(AddTable));
              _tp1->add = (-1)*4*(++_counter);/////������:_counter�Ǿֲ������ļ�������Ϊʲôǰ���Ǹ��ţ���ΪX86��ջ��ַ��������������ջ���ǵ͵�ַ����
			  _tp1->next = NULL;
              _tp1->type=temptype;
              strcpy(_tp1->id,newcode[opasmindex].var3);
			  optiasmout<<"\tpush\teax"<<endl;
			  if(_h1 == NULL)                                                // �����ֲ����ű���
			  {
				_h1 = _tp1;
				_he1 = _tp1;
			  }
			  else
			  {
				_he1->next = _tp1;
				_he1 = _he1->next;
			  }
            }
         else if(strcmp(newcode[opasmindex].op,"para") == 0) // �г��������β���ָ��ĵ�ַ
		{
			_tp1 = (AddTable*)malloc(sizeof(AddTable));
			_tp1->add = 4 * (6 + _varc--);///�����ֳ�5���Ĵ�����push��һ��retaddress����Ӧ��+6,_varc--�������ǵ���ѹջ ����һ������������ջ��
			///�βε�ַӦ��ָ��ʵ�ε�ʵ�ʵ�ַ��ʵ�ε�ַ�����ں�����ebp�·����ɵ����߾����ģ�
			////��ǰ��espΪebp
			_tp1->next = NULL;
			strcpy(_tp1->id,newcode[opasmindex].var3);
            if(strcmp(newcode[opasmindex].var1,"char") == 0)
            _tp1->type=1;
            if(strcmp(newcode[opasmindex].var1,"int") == 0)
            _tp1->type=0;
			if(_h1 == NULL)
			{
				_h1  = _tp1;///�β��ں����ڱ�ʹ��ʱҲ�����ֲ�����
				_he1 = _tp1;
			}
			else
			{
				_he1->next = _tp1;
				_he1 = _he1->next;
			}
		}
		else if(strcmp(newcode[opasmindex].op,"add") == 0 || strcmp(newcode[opasmindex].op,"sub") == 0 || strcmp(newcode[opasmindex].op,"mul") == 0 || strcmp(newcode[opasmindex].op,"div") == 0) // + - * /
           {
               int temptype1=0;
               int temptype2=0;
               // ��2������
			_read = _search(_h1,newcode[opasmindex].var2);//////��2��ԭ�������Ƿ��Ǿֲ�����
			if(_read == NULL)
			{
				_read = _search(_h2,newcode[opasmindex].var2);/////�Ƿ���ʱ����
				if(_read == NULL)
				{

				//////ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                _read=_search(_h3,newcode[opasmindex].var2);
                                if(_read==NULL){////����
                                    if(newcode[opasmindex].var2[0]>='0'&&newcode[opasmindex].var2[0]<='9')
                                    optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var2<<endl;
                                    else
                                     optiasmout<<"\tmov\teax,\t\'"<<newcode[opasmindex].var2<<'\''<<endl;
                                }

                                else{
                                     optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var2<<endl;
                                     temptype2=_read->type;
                                }

                            }
                            else {////����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                _read=_search(_h3,newcode[opasmindex].var2);

                                temptype2=_read->type;

                                for(;i<templen;i++)
                                temp[i]='\0';/////ȥ������ķ�����

                            strcpy(newcode[opasmindex].var2,temp);
                            int d=_findarraybase(newcode[opasmindex].var2);
                            if(d==-1)
                            optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var2<<"+4*ecx"<<"]"<<endl;
                            else{
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }

                            }


				}
				else////����ʱ����
				{
                    optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
                    temptype2=_read->type;
				}
			}
			else ////�Ǿֲ�����
			{
				optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
				temptype2=_read->type;
			}

			optiasmout<<"\tmov\tebx,\teax"<<endl;/////��2��������������ebx

			// ��1��Դ������
			_read = _search(_h1,newcode[opasmindex].var1);
			if(_read == NULL)
			{
				_read = _search(_h2,newcode[opasmindex].var1);
				if(_read == NULL)
				{
				    //ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                _read=_search(_h3,newcode[opasmindex].var1);
                                 if(_read==NULL){////����
                                    if(newcode[opasmindex].var1[0]>='0'&&newcode[opasmindex].var1[0]<='9')
                                    optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var1<<endl;
                                    else
                                     optiasmout<<"\tmov\teax,\t\'"<<newcode[opasmindex].var1<<'\''<<endl;
                                }
                                else{
                                    optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var1<<endl;
                                    temptype1=_read->type;
                                }

                            }
                            else {////����
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                _read=_search(_h3,newcode[opasmindex].var1);
                                temptype1=_read->type;
                                for(;i<templen;i++)
                                temp[i]='\0';
                            strcpy(newcode[opasmindex].var1,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)
                            optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }

                            }

					//optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var1<<endl;
				}
				else////����ʱ����
				{
					 optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
					 temptype1=_read->type;
				}
			}
			else////�Ǿֲ�����
			{
				optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
				temptype1=_read->type;
			}

			// deal with the operand
			if(strcmp(newcode[opasmindex].op,"add") == 0 || strcmp(newcode[opasmindex].op,"sub") == 0)
			{
				optiasmout<<'\t'<<newcode[opasmindex].op<<"\teax,\tebx"<<endl;/////add eax, ebx��sub eax,ebx
			}
			else/////imul ,div ebx   /////�˳�����ʱ��Ҫ����չָ��.
			{
			    optiasmout<<"\tcdq"<<endl;
				optiasmout<<"\ti"<<newcode[opasmindex].op<<"\tebx"<<endl;///eax=eax*/ebx
			}

			// ���������������ֵ

			_read = _search(_h1,newcode[opasmindex].var3);
			if(_read == NULL)///��ʱ����
			{
				_read = _search(_h2,newcode[opasmindex].var3);////����ʱ�������в���
				if(_read == NULL)
				{
					_read = _search(_h3,newcode[opasmindex].var3);///��Ҫ�ǲ���ȫ�ֵı���
					if(_read == NULL)   // ������Ҳ�����˵�����Ǹ��µ���ʱ����
					{
						_tp1 = (AddTable *)malloc(sizeof(AddTable));
						strcpy(_tp1->id,newcode[opasmindex].var3);
						_tp1->add = (-4)*(++_counter) ;
						_tp1->next = NULL;
                        if(temptype1==1&&temptype2==1)
                            _tp1->type=0;
                        else
                            _tp1->type=0;
						if(_h2 == NULL)///�������ʱ�������ڷ�����ʱ����������
						{
							_h2 = _tp1;
							_he2 = _tp1;
						}
						else
						{
							_he2->next = _tp1;
							_he2 = _he2->next;
						}
                          optiasmout<<"\tmov\tdword  ptr [ebp+("<<_tp1->add<<")],\teax"<<endl;/////��ʱ���������ڴ��С�������������
                          optiasmout<<"\tmov   ecx,ebp"<<endl;
                          optiasmout<<"\tadd   ecx,"<<_tp1->add<<endl;
                          optiasmout<<"\tcmp   esp ,ecx"<<endl;
                          optiasmout<<"\tjle  labn"<<_templabnumber<<endl;
                          optiasmout<<"\tmov esp,ecx"<<endl;
                          optiasmout<<"lab"<<_templab<<_templabnumber<<":"<<endl;////////֮������ôд��Ϊ���Ǳ�֤ѭ����ʱ����ʱ����ֻ��pushһ��.
                          _templabnumber++;
					}
					else				//Ϊȫ�ֱ���
					{
						optiasmout<<"\tmov _"<<newcode[opasmindex].var3<<",\teax"<<endl;
						if(temptype1==1&&temptype2==1)
                            _read->type=0;
                        else
                            _read->type=0;
					}
				}
				else////��ʱ����
				{
					optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
					if(temptype1==1&&temptype2==1)
                       _read->type=0;
                    else
                       _read->type=0;
				}
			}
			else////�ֲ�����
			{
				optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
				if(temptype1==1&&temptype2==1)
                _read->type=0;
                else
                _read->type=0;
			}

           }
           else if(strcmp(newcode[opasmindex].op,"scanf") == 0) // the _read sb statement
		   {
			_read = _search(_h1,newcode[opasmindex].var3);
			if(_read == NULL)
			{
				_read = _search(_h2,newcode[opasmindex].var3);
				if(_read == NULL)////����ȫ�ֱ���
				{
					if(strcmp(newcode[opasmindex].var1,"int")==0)//////scanf int  a
					optiasmout<<"\tinvoke crt_scanf,SADD(\"%d\"),addr _"<<newcode[opasmindex].var3<<endl;
					else if(strcmp(newcode[opasmindex].var1,"char")==0)
                    optiasmout<<"\tinvoke crt_scanf,SADD(\"%c\"),addr _"<<newcode[opasmindex].var3<<endl;
                }
				else//// ��ʱ����
				{
					if(strcmp(newcode[opasmindex].var1,"int")==0)
					optiasmout<<"\tinvoke crt_scanf,SADD(\"%d\"),addr "<<"dword ptr[ebp+("<<_read->add<<")]"<<endl;////invoke crt_scanf,SADD("%d"),addr dword ptr [ebp]
					else if(strcmp(newcode[opasmindex].var1,"char")==0)
                    optiasmout<<"\tinvoke crt_scanf,SADD(\"%c\"),addr "<<"dword ptr[ebp+("<<_read->add<<")]"<<endl;
				}
			}
			else  // �ֲ�����
			{
				if(strcmp(newcode[opasmindex].var1,"int")==0)
				optiasmout<<"\tinvoke crt_scanf,SADD(\"%d\"),addr "<<"dword ptr[ebp+("<<_read->add<<")]"<<endl;////invoke crt_scanf,SADD("%d"),addr dword ptr [ebp]
				else if(strcmp(newcode[opasmindex].var1,"char")==0)
                optiasmout<<"\tinvoke crt_scanf,SADD(\"%c\"),addr "<<"dword ptr[ebp+("<<_read->add<<")]"<<endl;
			}
		}

        else if(strcmp(newcode[opasmindex].op,"print") == 0)  // the write statement
		{
		     optiasmout<<";print begin===="<<endl;
		     optiasmout<<"\tpush eax"<<endl;
			if(strcmp(newcode[opasmindex].var1,"\0") != 0)/////���ַ���������ȴ�ӡ�ַ���
			{
                char buf[100];
                strcpy(buf,newcode[opasmindex].var1);
                optiasmout<<";print string===="<<endl;
                optiasmout<<"invoke crt_printf,ADDR literal(\""<<buf<<"\")"<<endl;
                optiasmout<<"invoke crt_printf,SADD(\"%c\"),"<<10<<endl;
                optiasmout<<";print string over===="<<endl;
			}
			if(strcmp(newcode[opasmindex].var2," ")!=0)/////��ӡ�Ķ����б���ʽ
			{
				_read = _search(_h1,newcode[opasmindex].var2);////�ھֲ�����������
				if(_read == NULL)
				{
					_read = _search(_h2,newcode[opasmindex].var2);                      // _h2����ʱ������ͷ
					if(_read == NULL)
					{
					        //AddTable* _readtemp=_read;////getvalueofarray()������ı�_readָ�룬��ӡ���ܳ���
						    /////�ھֲ���������ʱ���������Ҳ�����Ҫô��ȫ�ֱ���Ҫô�����顣
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen){////��������
                            _read = _search(_h3,newcode[opasmindex].var2);
                            if(_read == NULL)   // ��ʱ�����Ǵ��һ�����������ַ��ˡ�
						     {
						    if(newcode[opasmindex].var2[0]>='0'&&newcode[opasmindex].var2[0]<='9')
                             {
                                optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var2<<endl;
                                optiasmout<<"invoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;////��ӡ����
                             }
                             else{
                                optiasmout<<"\tmov\teax,\t\'"<<newcode[opasmindex].var2<<"\'"<<endl;
                                optiasmout<<"invoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
                            }
                          }
                          else {////��ͨȫ�ֱ���
                                optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var2<<endl;
                                if(_read->type==0)
                                optiasmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                                if(_read->type==1)
                                optiasmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                          }
                        }

						else////������
						{
						    AddTable* _readtemp=_read;////getvalueofarray()������ı�_readָ�룬��ӡ���ܳ���
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var2<<endl;
                                if(_read->type==0)
                                optiasmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                                if(_read->type==1)
                                optiasmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;////��ӡ����ȫ�ֵ�
                            }
                            else {////�������
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }

                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);////��Ϊ���������ı�_read
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(newcode[opasmindex].var2,temp);
                                int d=_findarraybase(temp);
                                if(d==-1)////ȫ���������
                                 {
                                     optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var2<<"+4*ecx]"<<endl;
                                     strcat(temp,"[0]");
                                     _readtemp = _search(_h3,temp);
                                 }
                                else
                                {
                                    strcat(temp,"[0]");
                                    _readtemp = _search(_h1,temp);
                                    optiasmout<<"\tneg ecx"<<endl;
                                    optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                                }
                                if(_readtemp->type==0)
                                optiasmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;
                                if(_readtemp->type==1)
                                optiasmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
                                }

						}
					}
					else/////�Ǹ���ʱ����
					{
						optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
						if(_read->type==0)
                        optiasmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;
                        if(_read->type==1)
                        optiasmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
					}
				}
				else///�Ǹ��ֲ�����
				{

					optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
					if(_read->type==0)
                    optiasmout<<"\tinvoke crt_printf,SADD(\"%d \"),"<<"eax"<<endl;
                    if(_read->type==1)
                    optiasmout<<"\tinvoke crt_printf,SADD(\"%c \"),"<<"eax"<<endl;
				}
			}
			 optiasmout<<"\tpop eax"<<endl;
			 optiasmout<<";print over===="<<endl;
		}


		else if(strcmp(newcode[opasmindex].op,"call") == 0)  // call functions
		{
		    char tempstr[30];
			strcpy(_str,newcode[opasmindex].var1);
			strcpy(tempstr,newcode[opasmindex].var3);
			optiasmout<<"\tcall\t"<<_str<<endl;
			///��������ǰ����push++��
			optiasmout<<"\tadd\tesp,\t"<<4*_push<<endl;////���κ������ù����������
			_push = 0;///���pushֵ
			//opasmindex++;
			/////�����������������ķ���ֵ����Ҫ��(�������Ӳ�������)
			//if(opasmindex<newcodelen && strcmp(newcode[opasmindex].op,"mov") == 0 && strcmp() == 0 )
			if(opasmindex<newcodelen && strcmp(tempstr," ") != 0 )/////������Ϊ����
			{
				_read = _search(_h1,tempstr);
				if(_read != NULL)
				{
					optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
                    if(strcmp(newcode[opasmindex].var2,"int") == 0)
                        _read->type=0;
                    if(strcmp(newcode[opasmindex].var2,"char") == 0)
                        _read->type=1;
				}
				else
				{
					_read = _search(_h2,tempstr);
					if(_read == NULL)
					{
						_read = _search(_h3,tempstr);
						if(_read == NULL)// �����ʱ�����������ɵģ���Ҫ��������ռ䡣
						{
							_tp1 = (AddTable*)malloc(sizeof(AddTable));
							_tp1->add = (-1)*4*(++_counter);
							strcpy(_tp1->id,tempstr);
							_tp1->next = NULL;
							if(strcmp(newcode[opasmindex].var2,"int") == 0)
                                  _tp1->type=0;
                            if(strcmp(newcode[opasmindex].var2,"char") == 0)
                                  _tp1->type=1;
							optiasmout<<"\tmov\tdword  ptr [ebp+("<<_tp1->add<<")],\teax"<<endl;/////��ʱ���������ڴ��С�������������
                            optiasmout<<"\tmov   ecx,ebp"<<endl;
                            optiasmout<<"\tadd   ecx,"<<_tp1->add<<endl;
                            optiasmout<<"\tcmp   esp ,ecx"<<endl;
                            optiasmout<<"\tjle  labn"<<_templabnumber<<endl;
                            optiasmout<<"\tmov esp,ecx"<<endl;
                            optiasmout<<"lab"<<_templab<<_templabnumber<<":"<<endl;////////֮������ôд��Ϊ���Ǳ�֤ѭ����ʱ����ʱ����ֻ��pushһ��.
                            _templabnumber++;
							if(_h2 == NULL)
							{
								_h2 = _tp1;
								_he2 = _tp1;
							}
							else
							{
								_he2->next = _tp1;
								_he2 = _he2->next;
							}
						}
						else
						{
							optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
							if(strcmp(newcode[opasmindex].var2,"int") == 0)
                                 _read->type=0;
                             if(strcmp(newcode[opasmindex].var2,"char") == 0)
                                _read->type=1;
						}
					}
					else
					{
						optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
						if(strcmp(newcode[opasmindex].var2,"int") == 0)
                           _read->type=0;
                       if(strcmp(newcode[opasmindex].var2,"char") == 0)
                           _read->type=1;
					}
				}
			}
			else
				{opasmindex++; continue;}
		}



		else if(strcmp(newcode[opasmindex].op,"mov") == 0)  // mov src1,src2,src3
		{
			// ��һ��ָ��ѵ�1���������ŵ��Ĵ�����
			int temptype=0;
			_read = _search(_h1,newcode[opasmindex].var1);
			if(_read == NULL)
			{
				_read =_search(_h2,newcode[opasmindex].var1);
				if(_read == NULL)
				{
					_read = _search(_h3,newcode[opasmindex].var1);
					if(_read != NULL){/////ȫ��
					    AddTable* _readtemp=_read;////getvalueofarray������ı�_readָ��
					    if(strcmp(newcode[opasmindex].var2," ")!=0)///////ȫ�ֶ��������
                        {

                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            for(;i<templen;i++)
                                temp[i]='\0';
                             _getvalueofarry(newcode[opasmindex].var2);
                            strcpy(newcode[opasmindex].var1,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)
                            optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var1<<"+4*ecx]"<<endl;
                            else{
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }


                        }
						else{///��ͨȫ�ֱ���

                            optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var1<<endl;
						}
                      temptype=_readtemp->type;

					}
					else
                         // mov	i 	6�����
                        if(newcode[opasmindex].var1[0]>='0'&&newcode[opasmindex].var1[0]<='9')
                        {
                            optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var1<<endl;
                            }
                        else
						{
						    optiasmout<<"\tmov\teax,\t\'"<<newcode[opasmindex].var1<<'\''<<endl;temptype=1;
						    }
				}
				else////��ʱ����
				{
					optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
					temptype=_read->type;
				}
			}
			else///�ֲ�����
			{
			    optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
			    temptype=_read->type;
			}

			// �ڶ���ָ��ٰѼĴ����е����ݷŵ���3����������
			_read = _search(_h1,newcode[opasmindex].var3);
			if(_read == NULL)
			{
				_read = _search(_h2,newcode[opasmindex].var3);
				if(_read == NULL)
				{
					_read = _search(_h3,newcode[opasmindex].var3);
					if(_read != NULL)  // Ӧ����_read ��Ϊ�յġ���Ȼ���д����
						 {

                          if(strcmp(newcode[opasmindex].var2," ")!=0)///////ȫ�ֶ��������
                          {

                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            for(;i<templen;i++)
                                temp[i]='\0';
                             _getvalueofarry(newcode[opasmindex].var2);
                            strcpy(newcode[opasmindex].var3,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)
                            optiasmout<<"\tmov\tdword ptr["<<newcode[opasmindex].var3<<"+4*ecx] "<<",eax"<<endl;
                            else{
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\tdword ptr[ebp+"<<d<<"+4*ecx] "<<",eax"<<endl;
                            }

                        }
						   else ///��ͨȫ�ֱ���
						      optiasmout<<"\tmov\t_"<<newcode[opasmindex].var3<<",\teax"<<endl;
						      //_read->type=temptype;
                    }
					else if(_read == NULL)// ��������ʱ�����������ɵģ���Ҫ��������ռ䡣Ӧ���ǲ�Ϊ�յģ�Ϊ�˴��밲ȫ��
                        /////change[$0]�����Ҳ������
						{
                           if(strcmp(newcode[opasmindex].var2," ")!=0&&newcode[opasmindex].var2[0]!=0)///////ȫ�ֶ��������
                            {
                            int templen;
                            int i;
                            char temp[30];

                            //strcpy(newcode[opasmindex].var2,temp);

                            strcpy(temp,newcode[opasmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                for(;i<templen;i++)
                                temp[i]='\0';
                            _getvalueofarry(valueofarry);
                            strcpy(newcode[opasmindex].var3,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)
                            optiasmout<<"\tmov\tdword ptr["<<newcode[opasmindex].var3<<"+4*ecx] "<<",eax"<<endl;
                            else{
                                optiasmout<<"\t neg ecx"<<endl;
                                optiasmout<<"\tmov\tdword ptr[ebp+("<<d<<")+4*ecx] "<<",eax"<<endl;
                            }

                        }

						    else{/////�����ɵ���ʱ����

							_tp1 = (AddTable*)malloc(sizeof(AddTable));
							_tp1->add = (-1)*4*(++_counter);
							strcpy(_tp1->id,newcode[opasmindex].var3);
							_tp1->next = NULL;
							_tp1->type=temptype;
							optiasmout<<"\tmov\tdword  ptr [ebp+("<<_tp1->add<<")],\teax"<<endl;/////��ʱ���������ڴ��С�������������
                            optiasmout<<"\tmov   ecx,ebp"<<endl;
                            optiasmout<<"\tadd   ecx,"<<_tp1->add<<endl;
                            optiasmout<<"\tcmp   esp ,ecx"<<endl;
                            optiasmout<<"\tjle  labn"<<_templabnumber<<endl;
                            optiasmout<<"\tmov esp,ecx"<<endl;
                            optiasmout<<"lab"<<_templab<<_templabnumber<<":"<<endl;////////֮������ôд��Ϊ���Ǳ�֤ѭ����ʱ����ʱ����ֻ��pushһ��.
                            _templabnumber++;
							if(_h2 == NULL)
							{
								_h2 = _tp1;
								_he2 = _tp1;
							}
							else
							{
								_he2->next = _tp1;
								_he2 = _he2->next;
							}
                          }
						}
				}
				else///��ʱ����
				{
					optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
					_read->type=temptype;
				}
			}
			else///�ֲ�����
			{
				optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
				//_read->type=temptype;
			}
		}


		else if(strcmp(newcode[opasmindex].op,"ret") == 0)  // ����
		{
			//retFlag = 1;
			if(strcmp(newcode[opasmindex].var3," ") != 0)  // return some value.
			{
				_read = _search(_h1,newcode[opasmindex].var3);
				if(_read != NULL) // ����Ǿֲ�����
				{
					optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
                    //optiasmout<<"\tadd\tesp,\t"<<4*_counter<<endl;
                    optiasmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
					_popreg();
					optiasmout<<"\tret"<<endl;
					//_read->type=_functiontype;
				}
				else
				{
					_read = _search(_h2,newcode[opasmindex].var3);
					if(_read != NULL)            // ������ʱ����
					{
						optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
						//optiasmout<<"\tadd\tesp,\t"<<4*_counter<<endl;
						optiasmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
						_popreg();
						optiasmout<<"\tret"<<endl;
						_read->type=_functiontype;
					}
					else////ȫ��
					{
					    _read =  _search(_h3,newcode[opasmindex].var3);
					    if(_read==NULL)
					    optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var3<<endl;
                        else
						 {
						     optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var3<<endl;
						     //_read->type=_functiontype;
						     }
						//optiasmout<<"\tadd\tesp,\t"<<4*_counter<<endl;
						optiasmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
						_popreg();
                        optiasmout<<"\tret"<<endl;
					}
				}
			}
			else////return ;
			{
				        //optiasmout<<"\tadd\tesp,\t"<<4*_counter<<endl;
				        optiasmout<<'\t'<<"mov"<<'\t'<<"esp,"<<'\t'<<"ebp"<<endl;
						_popreg();
						opasmindex22=opasmindex+1;
						if(!(strcmp(newcode[opasmindex22].op,"end")==0&&strcmp(newcode[opasmindex22].var3,"main")==0))
                        optiasmout<<"\tret"<<endl;
			}
			   _functiontype=-1;////��������Ѻ����ķ�����������һ��

			opasmindex++;
			if(strcmp(newcode[opasmindex].op,"end") == 0)
			{
			    _counter = 0;						// �����������ü�����Ϊ0
                _Destroy(_h1);                        //�������ڵľֲ��������Լ���ʱ������ȫ�����
			    _h1 = NULL;
			    _Destroy(_h2);
                _h2 = NULL;
                if(strcmp(newcode[opasmindex].var3,"main") == 0)
                     continue;//�����main�Ļ�ֱ�Ӽ���,����������һ��end��䡭����Ԫʽ��Ƶ���©
				optiasmout<<'_'<<function<<"\tendp"<<endl;
				opasmindex++;
				continue;
			}
		}

        ///sma,seq,lar,leq,neq,eql����ת�����;
      else if(strcmp(newcode[opasmindex].op,"sma") == 0||strcmp(newcode[opasmindex].op,"seq") == 0||strcmp(newcode[opasmindex].op,"lar") == 0||
                strcmp(newcode[opasmindex].op,"leq") == 0 ||strcmp(newcode[opasmindex].op,"neq") == 0 ||strcmp(newcode[opasmindex].op,"eql") == 0 )  // ���Ƚϵ�
		{
			_read = _search(_h1,newcode[opasmindex].var2);   // the second argument
			if(_read == NULL)
			{
				_read = _search(_h2,newcode[opasmindex].var2);
				if(_read == NULL)
				{
				    _read=_search(_h3,newcode[opasmindex].var2);
				    if(_read==NULL){
                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                        if(i==templen)/////����
                        {
                        if(newcode[opasmindex].var2[0]>='0'&&newcode[opasmindex].var2[0]<='9')
                        optiasmout<<"\tmov\tebx,\t"<<newcode[opasmindex].var2<<endl;
                        else
                        optiasmout<<"\tmov\tebx,\t\'"<<newcode[opasmindex].var2<<"\'"<<endl;
                        }
                        else{///change[$0]
                               char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(newcode[opasmindex].var2,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            optiasmout<<"\tmov\tebx,\tdword ptr["<<newcode[opasmindex].var2<<"+4*ecx]"<<endl;
                            else
                            {
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\tebx,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                        }

				    }

					else
                    {
                            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var2);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            optiasmout<<"\tmov\tebx,\t_"<<newcode[opasmindex].var2<<endl;
                            else{///����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(newcode[opasmindex].var2,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            optiasmout<<"\tmov\tebx,\tdword ptr["<<newcode[opasmindex].var2<<"+4*ecx]"<<endl;
                            else
                            {
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\tebx,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                        }
                    }

				}
				else
				{
					optiasmout<<"\tmov\tebx,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
				}
			}
			else
			{
				optiasmout<<"\tmov\tebx,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
			}

			_read = _search(_h1,newcode[opasmindex].var1);
			if(_read == NULL)
			{
				_read = _search(_h2,newcode[opasmindex].var1);
				if(_read == NULL)
				{
				    _read=_search(_h3,newcode[opasmindex].var1);
				    if(_read==NULL){
                         int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                        if(i==templen)/////����
                        {
                        if(newcode[opasmindex].var1[0]>='0'&&newcode[opasmindex].var1[0]<='9')
                        optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var1<<endl;
                        else
                       optiasmout<<"\tmov\teax,\t\'"<<newcode[opasmindex].var1<<"\'"<<endl;
                        }
                       else {
                               char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(newcode[opasmindex].var1,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                           optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                               optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                       }
				    }

					else{
                           int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var1<<endl;
                            else{/////����ȫ�ֱ���
                                 char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }//////temp�������������
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                                strcpy(newcode[opasmindex].var1,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)////����ȫ�ֱ���
                            optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx"<<"]"<<endl;
                            }
                        }
					}


				}
				else
				{
					optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
				}
			}
			else
			{
				optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
			}

			optiasmout<<"\tcmp\teax,\tebx"<<endl;///�����Ƚ�
			if(strcmp(newcode[opasmindex].op,"sma") == 0){
                optiasmout<<"\tjnge\t"<<newcode[opasmindex].var3<<endl;
			}

			if(strcmp(newcode[opasmindex].op,"seq") == 0){
                optiasmout<<"\tjle\t"<<newcode[opasmindex].var3<<endl;
			}

			if(strcmp(newcode[opasmindex].op,"lar") == 0){
                optiasmout<<"\tjnle\t"<<newcode[opasmindex].var3<<endl;
			}

			if(strcmp(newcode[opasmindex].op,"leq") == 0){
                optiasmout<<"\tjge\t"<<newcode[opasmindex].var3<<endl;
			}
			if(strcmp(newcode[opasmindex].op,"eql") == 0){
                optiasmout<<"\tjz\t"<<newcode[opasmindex].var3<<endl;
			}
			if(strcmp(newcode[opasmindex].op,"neq") == 0){
                optiasmout<<"\tjnz\t"<<newcode[opasmindex].var3<<endl;
			}
		}

        else if(strcmp(newcode[opasmindex].op,"jmp") == 0){
            optiasmout<<"\tjmp\t"<<newcode[opasmindex].var3<<endl;
        }
        else if(strcmp(newcode[opasmindex].op,"opp") == 0){////ȡ������
            int temptype=0;
            _read = _search(_h1,newcode[opasmindex].var1);//////��һ��ԭ�������Ƿ��Ǿֲ�����
			if(_read == NULL)
			{
				_read = _search(_h2,newcode[opasmindex].var1);/////�Ƿ���ʱ����
				if(_read == NULL)
				{
				    _read = _search(_h3,newcode[opasmindex].var1);
				   if(_read ==NULL)
				      optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var1<<endl;
                    else
                    {
                        //ȫ�ֱ������߳�������ֱ����,����Ҫ����Ե�ַ
				            int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var1);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                _read=_search(_h3,newcode[opasmindex].var1);
                                if(_read==NULL)
                                optiasmout<<"\tmov\teax,\t"<<newcode[opasmindex].var1<<endl;
                                else{
                                    optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var1<<endl;
                                    temptype=_read->type;
                                }

                            }
                            else {////����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                _read=_search(_h3,newcode[opasmindex].var1);
                                temptype=_read->type;
                                for(;i<templen;i++)
                                temp[i]='\0';
                            strcpy(newcode[opasmindex].var1,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)
                            optiasmout<<"\tmov\teax,\tdword ptr["<<newcode[opasmindex].var1<<"+4*ecx]"<<endl;
                            else
                            {
                                optiasmout<<"\t neg ecx"<<endl;
                                optiasmout<<"\tmov\teax,\tdword ptr[ebp+("<<d<<")+4*ecx]"<<endl;
                            }

                            }

                        optiasmout<<"\tmov\teax,\t_"<<newcode[opasmindex].var1<<endl;
                        temptype=_read->type;
                    }
				}
				else////����ʱ����
				{
                    optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
                    temptype=_read->type;
				}
			}
			else ////�Ǿֲ�����
			{
				optiasmout<<"\tmov\teax,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
                   temptype=_read->type;
			}
			optiasmout<<"\tneg\teax"<<endl;///ȡ��
			// ���������������ֵ

			_read = _search(_h1,newcode[opasmindex].var3);
			if(_read == NULL)///��ʱ����
			{
				_read = _search(_h2,newcode[opasmindex].var3);////����ʱ�������в���
				if(_read == NULL)///��ʱ���������Ҳ���
				{
					_read = _search(_h3,newcode[opasmindex].var3);///��Ҫ�ǲ���ȫ�ֵı���
					if(_read == NULL)   // ������Ҳ�����˵�����Ǹ��µ���ʱ����
					{
						_tp1 = (AddTable *)malloc(sizeof(AddTable));
						strcpy(_tp1->id,newcode[opasmindex].var3);
						_tp1->add = (-4)*(++_counter) ;
						_tp1->next = NULL;
                        _tp1->type=temptype;
						if(_h2 == NULL)///�������ʱ�������ڷ�����ʱ����������
						{
							_h2 = _tp1;
							_he2 = _tp1;
						}
						else
						{
							_he2->next = _tp1;
							_he2 = _he2->next;
						}
                          optiasmout<<'\t'<<"push\teax"<<endl;/////��ʱ���������ڴ��С�������������
					}
					else				//Ϊȫ�ֱ���
					      {
					        int templen;
                            int i;
                            char temp[30];
                            strcpy(temp,newcode[opasmindex].var3);
                            templen = strlen(temp);
                            for(i=0;i<templen;i++)
                                if(temp[i]=='[')
                                break;
                            if(i==templen)/////��ͨȫ�ֱ���
                            {
                                _read=_search(_h3,newcode[opasmindex].var3);
                                if(_read==NULL)
                                optiasmout<<"\tmov "<<newcode[opasmindex].var3<<",\teax"<<endl;
                                else{
                                 optiasmout<<"\tmov _"<<newcode[opasmindex].var3<<",\teax"<<endl;
                                }

                            }
                            else {////����ȫ�ֱ���
                                char valueofarry[30];
                                int j;
                                int k=0;
                                for(j=i+1;j<templen;j++){
                                    if(temp[j]!=']')
                                    valueofarry[k++]=temp[j];
                                }
                                valueofarry[k]='\0';
                                _getvalueofarry(valueofarry);
                                for(;i<templen;i++)
                                temp[i]='\0';
                            strcpy(newcode[opasmindex].var1,temp);
                            int d=_findarraybase(temp);
                            if(d==-1)
                            optiasmout<<"\tmov dword ptr["<<newcode[opasmindex].var3<<"+4*ecx]"<<",\teax"<<endl;
                            else
                            {
                                optiasmout<<"\tneg ecx"<<endl;
                                optiasmout<<"\tmov dword ptr[ebp+("<<d<<")+4*ecx]"<<",\teax"<<endl;
                            }

                            }

                        //optiasmout<<"\tmov _"<<newcode[opasmindex].var3<<",\teax"<<endl;
						//_read->type=temptype;

				      }
				}
				else////��ʱ����
				{
					optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
					_read->type=temptype;
				}
			}
			else////�ֲ�����
			{
				optiasmout<<"\tmov\tdword  ptr [ebp+("<<_read->add<<")],\teax"<<endl;
				//_read->type=temptype;
			}
		 }


     opasmindex++;
  }
      optiasmout<<"; Դ�������"<<endl;
      optiasmout.close();

}

void _popreg(){
    optiasmout<<";-------------�ָ��Ĵ���-----------"<<endl;
	optiasmout<<'\t'<<"pop"<<'\t'<<"ebp"<<endl;
	//optiasmout<<'\t'<<"pop"<<'\t'<<"ebx"<<endl;
	optiasmout<<'\t'<<"pop"<<'\t'<<"edi"<<endl;
	optiasmout<<'\t'<<"pop"<<'\t'<<"esi"<<endl;
	optiasmout<<'\t'<<"pop"<<'\t'<<"edx"<<endl;
	optiasmout<<'\t'<<"pop"<<'\t'<<"ecx"<<endl;
	optiasmout<<'\t'<<"pop"<<'\t'<<"ebx"<<endl;
}


AddTable* _search(AddTable * _head, char *id)
{
	AddTable *t = _head;
	while(t != NULL)
	{
		if(strcmp(t->id,id) == 0)
			return t;
		t = t->next;
	}

	return NULL;
}
void _Destroy(AddTable* _head)
{
	if(_head == NULL)
		return;
	else
	{
		_Destroy(_head->next);
		free(_head);
	}
}

void _getvalueofarry(char *s){

    // ��һ��ָ��ѵ�1���������ŵ��Ĵ�����
            char name[30];
            strcpy(name,s);
			_read = _search(_h1,name);
			if(_read == NULL)
			{
				_read =_search(_h2,name);
				if(_read == NULL)
				{
					_read = _search(_h3,name);
					if(_read != NULL){/////ȫ�ֻ��߳���

                            optiasmout<<"\tmov\tecx,\t_"<<name<<endl;

					}
					else
                         // mov	i 	6�����
						optiasmout<<"\tmov\tecx,\t"<<name<<endl;
				}
				else////��ʱ����
				{
					optiasmout<<"\tmov\tecx,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
				}
			}
			else///�ֲ�����
			{
			    optiasmout<<"\tmov\tecx,\tdword  ptr [ebp+("<<_read->add<<")]"<<endl;
			}


    /////ecx�ݴ�valueofarray
}
int _findarraybase(char* s){////�����ҵ��ֲ�����ı����Ļ���ַ.change[0]��λ��
      char name[30];
      strcpy(name,s);
      strcat(name,"[0]");
      _read = _search(_h1,name);
      if(_read!=NULL)
      {
          return _read->add;
      }
      else return -1;////�Ҳ����Ļ�˵���Ǹ�ȫ�ֶ��������
}
