int main()
{
    int n;
    int s;
    s = 0;
    for n in (3..7)
    {
        s = s+n;
        print s;
    }
}