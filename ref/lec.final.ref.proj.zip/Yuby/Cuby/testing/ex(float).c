int main(){
    float a = 1.0;
    int b = 2;
    print a+b;
}