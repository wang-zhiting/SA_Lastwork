int main()
{
    int a=0;
    int b=7;
    int c = a>b?a:b;
}