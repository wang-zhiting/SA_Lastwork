#include "stdafx.h"
#include <iostream>
#include <string>
#include <string.h>
#include <stdlib.h>
#include "define.h"

using namespace std;
extern int symbol;//    { last symbol read }
extern char   id[30] ;///     { last identifier read��������ű������� }
extern int   number;   ///{ last number read }
extern int   err;   /// {*kk : last identifier length�� err����������� *}
extern int linenumer; /////number of line
extern string errorde[51];////error code
extern info Table[200];/////info table
extern middlecode code[1000];/////middle code
extern char tokenbuf[82]; //////������ַ����������ident�Ļ����Ӧ����ident��ֵ
extern char tempc;
extern FILE* fin;
extern void getsym();
extern void error(int e);


extern info Table[200];/////info table
extern middlecode code[1000];/////middle code


int lab=0;
int temp_value=0;
int codenum=0;
FILE* fp;


char* newlab(){
	char *p = (char *)malloc(10*sizeof(char));
	char q[10];
	memset(p,0,10*sizeof(char));
	p[0] = 'l';
	p[1] = 'a';
	p[2] = 'b';
	strcat(p,itoa(lab,q,10));
	lab++;
	return p;
}

char* newplace()
{
	char *p = (char *)malloc(10*sizeof(char));

	char q[10];
	memset(p,0,10*sizeof(char));
	p[0] = '$';
	itoa(temp_value,q,10);
	strcat(p,q);
	temp_value++;
	return p;
}

void emit(char op[],char name1[],char name2[],char name3[])
{
	strcpy(code[codenum].op,op);
	strcpy(code[codenum].var1,name1);
	strcpy(code[codenum].var2,name2);
	strcpy(code[codenum].var3,name3);
	codenum++;
}


void printmidcode()
{
	int i= 0;
    fp=fopen("midcode.txt","w+");
	while (i<codenum) {
		if (strcmp(code[i].op,"delete")!=0) {
			fprintf(fp,"%s,\t",code[i].op);
			fprintf(fp,"%s,\t",code[i].var1);
			fprintf(fp,"%s,\t",code[i].var2);
			fprintf(fp,"%s;\n",code[i].var3);
		}
		if (strcmp(code[i].op,"end")==0)
			fprintf(fp,"\n");
		i++;
	}
	fclose(fp);
	return;
}
