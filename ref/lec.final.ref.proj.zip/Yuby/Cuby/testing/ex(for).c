int main(){
    int i;
    i = 0;
    int n;
    n = 0;
    for(i =0 ; i < 5 ;  ++i){
        n = n + i;
    }
}