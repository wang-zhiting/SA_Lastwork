#include <iostream>
#include <string>
#include "tempprint.h"
#include "define.h"
using namespace std;

string tempprint[100];/////no use

void tempAssign(){//// no use
	tempprint[CONST]="CONSTTK";
	tempprint[INT]="INTTK";
	tempprint[VOID]="VOIDTK";
	tempprint[MAIN]="MAINTK";
	tempprint[IF]="IFTK";
	tempprint[ELSE]="ELSETK";
	tempprint[WHILE]="WHILETK";
	tempprint[SCANF]="SCANFTK";
	tempprint[PRINTF]="PRINTFTK";
	tempprint[RETURN]="RETURNTK";
	tempprint[SWITCH]="SWITCHTK";
	tempprint[CASE]="CASETK";
	tempprint[ident]="IDENT";
	tempprint[integer]="INT";
	tempprint[character]="CHARCON";
	tempprint[chstring]="STRCON";
	tempprint[PLUS]="PLUS";
	tempprint[MINUS]="MINU";
	tempprint[MUL]="MULT";
	tempprint[DEVIDE]="DIV";
	tempprint[R_BRACKET]="RPARENT";
	tempprint[L_BRACKET]="LPARENT";
	tempprint[R_M_BRACKET]="RBRACK";
	tempprint[L_M_BRACKET]="LBRACK";
	tempprint[R_B_BRACKET]="RBRACE";
	tempprint[L_B_BRACKET]="LBRACE";
	tempprint[SEMICOLON]="SEMICN";
	tempprint[COMMA]="COMMA";
	tempprint[QUOTATION]="QMARK";
	tempprint[DOUBLE_QUOTATION]="DQMARK";

	tempprint[SMALLER]="LSS";
	tempprint[SMALLER_EQUAL]="LEQ";
	tempprint[LARGER]="GRE";
	tempprint[LARGER_EQUAL]="GEQ";
	tempprint[EQUAL]="EQL";
	tempprint[NOT_EQUAL]="NEQ";
	tempprint[ASSIGN]="ASSIGN";

}
