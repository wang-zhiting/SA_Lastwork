TODO
======================================

 * Add support for lexing full range of tokens
 * Add parsing of full range of expressions
 * Investigate a nice pretty printing library (smart-print, unless I write my own based off Wadler's paper)

see `tmp/compiler` for original source code
also https://github.com/thizanne/tiger/blob/master/src/parser.mly for inspiration
