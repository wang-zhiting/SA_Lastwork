#include <iostream>
#include <string>
using namespace std;

extern string tempprint[100];
void tempAssign();

