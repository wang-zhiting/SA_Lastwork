int main(){
    int n;
    n = 0;
    int s;
    s = 0;
    while(n<5){
        s = s + n;
        n = n + 1;
    }
}