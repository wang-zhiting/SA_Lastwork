# C Library
This is the external C library used to suppport Dict, Graph, Node and List with thier APIs.
Test: Please run the commented main function to test.
